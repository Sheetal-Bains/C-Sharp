﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMSServices.PdfGeneration
{
    public class PdfHelper
    {
        public static void DrawWaterMark(PdfWriter writer, Document document)
        {
            Rectangle pageRectangle = document.PageSize;
            PdfContentByte content = writer.DirectContentUnder;
            BaseFont fnt = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

            content.SetFontAndSize(fnt, 60);

            PdfGState graphicsState = new PdfGState();
            graphicsState.FillOpacity = 0.4F;
            //set graphics state to pdfcontentbyte
            content.SetGState(graphicsState);
            //set color of watermark
            content.SetColorFill(BaseColor.LIGHT_GRAY);
            //indicates start of writing of text
            content.BeginText();
            //show text as per position and rotation
            content.ShowTextAligned(Element.ALIGN_CENTER, "DRAFT PRINT", pageRectangle.Width / 2, (pageRectangle.Height / 2) - 20, 45);
            //call endText to invalid font set
            content.EndText();
        }
    }
}