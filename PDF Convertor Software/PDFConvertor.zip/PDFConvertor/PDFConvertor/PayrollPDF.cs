﻿using HRMSBusinessEntityLayer.PayRoll;
using HRMSServices.PdfGeneration.Payroll;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace HRMSServices.PdfGeneration
{
    public class PayrollPDF
    {
        Font font_12f;
        Font font_12f_boldunderline;
        Font font_12f_bold;
        Font font_14f;
        Font font_16f;
        Font font_16f_bold;
        Font font_20f;
        Font font_20f_bold;

        public PayrollPDF()
        {
            BaseFont customfont = BaseFont.CreateFont(HostingEnvironment.MapPath("~/PdfGeneration/fonts/arialn.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED);
            
            font_12f = new Font(customfont, 12f);
            font_12f.Size = 12f;

            font_12f_boldunderline = new Font(font_12f);
            font_12f_boldunderline.SetStyle(Font.BOLD | Font.UNDERLINE);

            font_12f_bold = new Font(font_12f);
            font_12f_bold.SetStyle(Font.BOLD);

            font_14f = new Font(customfont, 14f);
            font_14f.Size = 14f;

            font_16f = new Font(customfont, 16f);
            font_16f.Size = 16f;

            font_16f_bold = new Font(customfont, 16f);
            font_16f_bold.Size = 16f;
            font_16f_bold.SetStyle(Font.BOLD);

            font_20f = new Font(customfont, 20f);
            font_20f.Size = 20f;

            font_20f_bold = new Font(customfont, 20f);
            font_20f_bold.Size = 20f;
            font_20f_bold.SetStyle(Font.BOLD);
        }

        public Boolean GenerateSalarySlip(BE_SalaryProcess_ReportSalarySlip data, Boolean IsDraft, String filename)
        {
            FileStream fs = null; Document doc = null; PdfWriter writer = null;
            Boolean rt = false;
            try
            {
                fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Write);
                doc = new Document(iTextSharp.text.PageSize.A2,36f,36f,72f,72f);
                writer = PdfWriter.GetInstance(doc, fs);

                SalarySlip slip = new SalarySlip(font_12f, IsDraft);
                rt = slip.GeneratePDF(data, doc, writer);

            }
            catch
            {
                rt = false;
            }
            finally
            {
                if (doc != null)
                {
                    if (doc.IsOpen())
                        doc.Close();
                    doc.Dispose();
                }
                if (writer != null)
                {
                    writer.Close(); writer.Dispose();
                }
                if (fs != null)
                {
                    fs.Close(); fs.Dispose();
                }

            }
            return rt;
        }

        public Boolean GenerateSalarySummary(BE_Report_SalarySummary data, Boolean IsDraft, String filename)
        {
            FileStream fs = null; Document doc = null; PdfWriter writer = null;
            Boolean rt = false;
            try
            {
                fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Write);
                doc = new Document();
                writer = PdfWriter.GetInstance(doc, fs);

                SalarySummary smry = new SalarySummary(font_14f, font_16f, font_16f_bold, font_20f, font_20f_bold, IsDraft);
                rt = smry.GeneratePDF(data, doc, writer);

            }
            catch
            {
                rt = false;
            }
            finally
            {
                if (doc != null)
                {
                    if (doc.IsOpen())
                        doc.Close();
                    doc.Dispose();
                }
                if (writer != null)
                {
                    writer.Close(); writer.Dispose();
                }
                if (fs != null)
                {
                    fs.Close(); fs.Dispose();
                }

            }
            return rt;
        }

        
    }
}