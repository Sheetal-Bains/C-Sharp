﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PDFConvertor
{
    public partial class PDFSamplePage : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = "sp_Bonus_CalculationForApril2017_March2018";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CompanyID", 1);
                    cmd.Parameters.AddWithValue("@EmployeeTypeID", 1);
                    cmd.Connection.Open();
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(ds);
                    }
                }
            }
            Response.Clear();
            Response.ClearHeaders();
            Response.ContentType = "application/pdf";
            Response.AppendHeader("Content-disposition", "inline;filename=Bonus.pdf");
            using (Document doc = new Document(iTextSharp.text.PageSize.A4.Rotate()))
            {
                using (PdfWriter writer = PdfWriter.GetInstance(doc, Response.OutputStream))
                {
                    try
                    {
                        writer.PageEvent = new Header();
                        doc.SetMargins(72f, 36f, 54f, 36f);
                        doc.Open();
                        #region Data

                        Font font_normal = new Font(Font.FontFamily.TIMES_ROMAN, 8f);
                        font_normal.SetStyle(Font.NORMAL);

                        Font font_bold = new Font(Font.FontFamily.TIMES_ROMAN, 8f);
                        font_bold.SetStyle(Font.BOLD);
                        Int32 rowno = 0;



                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            String depname = Convert.ToString(ds.Tables[1].Rows[i][0]);

                            if (i > 0)
                                doc.NewPage();

                            

                            if (i == 0)
                            {
                                PdfPTable company = new iTextSharp.text.pdf.PdfPTable(18);
                                company.WidthPercentage = 100f;
                                float[] comp_widths = new float[] { 4, 6, 14, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
                                company.SetWidths(comp_widths);
                                company.SpacingBefore = 10f;

                                PdfPCell company_hd = new PdfPCell(new Phrase(Convert.ToString(ds.Tables[0].Rows[0][0]), font_bold));
                                company_hd.Border = 0;
                                company_hd.Border = PdfPCell.TOP_BORDER;
                                company_hd.BorderColor = BaseColor.BLACK;
                                company_hd.BorderWidth = 1f;
                                company_hd.Padding = 7f;
                                company_hd.PaddingTop = 4f;
                                company_hd.PaddingLeft = 3f;
                                company_hd.Colspan = 4;
                                company.AddCell(company_hd);

                                company_hd = new PdfPCell(new Phrase("Detail of Month Wise Bonus + Exgratia For the Period of (2016-17)", font_normal));
                                company_hd.Border = 0;
                                company_hd.Border = PdfPCell.TOP_BORDER;
                                company_hd.BorderColor = BaseColor.BLACK;
                                company_hd.BorderWidth = 1f;
                                company_hd.Padding = 7f;
                                company_hd.PaddingTop = 4f;
                                company_hd.Colspan = 14;
                                company.AddCell(company_hd);
                                doc.Add(company);


                            }
                            PdfPTable bonus = new iTextSharp.text.pdf.PdfPTable(18);
                            bonus.WidthPercentage = 100f;
                            float[] widths = new float[] { 4, 6, 14, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
                            bonus.SetWidths(widths);
                            bonus.SpacingBefore = 10f;
                            bonus.HeaderRows = 2;

                            PdfPCell header_cell = new PdfPCell(new Phrase(depname, font_normal));
                            header_cell.Border = 0;
                            header_cell.Border = PdfPCell.TOP_BORDER;
                            header_cell.BorderColor = BaseColor.BLACK;
                            header_cell.BorderWidth = 1f;
                            header_cell.Padding = 7f;
                            header_cell.PaddingLeft = 3f;
                            header_cell.PaddingTop = 4f;
                            header_cell.Colspan = 18;
                            bonus.AddCell(header_cell);

                            setHeader(ref bonus, font_normal, 1);




                            DataRow[] dt1 = ds.Tables[2].Select("DeptName='" + depname + "'");
                            DataTable dt = new DataTable();
                            if (dt != null)
                                dt = dt1.OrderBy(x => x.Field<Int32>("SortOrder")).CopyToDataTable();

                            var dt_employees = dt.AsEnumerable().Select(x => new
                            {
                                EmpCode = x.Field<Int32>("SrEmpCode"),
                                EmployeeName = x.Field<String>("EmployeeName"),
                                SortOrd = x.Field<Int32>("SortOrder")
                            }).Distinct().OrderBy(y => y.SortOrd).ToList();

                            #region Department Wise Data

                            for (int j = 0; j < dt_employees.Count(); j++)
                            {
                                //Serial No
                                rowno = rowno + 1;
                                Int32 empcode = dt_employees[j].EmpCode;
                                var emplist = dt.AsEnumerable().Where(x => x.Field<Int32>("SrEmpCode") == empcode).OrderByDescending(x => x.Field<Int32>("SrYear")).OrderByDescending(y => y.Field<Int32>("SrMonth")).ToList();


                                PdfPCell data_cell = new PdfPCell(new Phrase(rowno.ToString(), font_normal));
                                data_cell.Border = 0;
                                data_cell.Padding = 3f;
                                bonus.AddCell(data_cell);

                                //Employee Code
                                data_cell = new PdfPCell(new Phrase(Convert.ToString(empcode), font_normal));
                                data_cell.Border = 0;
                                data_cell.Padding = 3f;
                                bonus.AddCell(data_cell);

                                var empdata = emplist[0];

                                if (empdata != null)
                                {
                                    //Employee Name
                                    data_cell = new PdfPCell(new Phrase(dt_employees[j].EmployeeName + Environment.NewLine + empdata.Field<String>("GradeCode") + Environment.NewLine + empdata.Field<String>("DesigName"), font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Padding = 3f;
                                    data_cell.SetLeading(0, 1.2f);
                                    bonus.AddCell(data_cell);

                                    //Columns
                                    data_cell = new PdfPCell(new Phrase("Wages" + Environment.NewLine + "BN_WG" + Environment.NewLine + "Bonus" + Environment.NewLine + "Exgr." + Environment.NewLine + "P.Days", font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Padding = 3f;

                                    data_cell.SetLeading(0, 1.2f);
                                    bonus.AddCell(data_cell);

                                    //data_cell = new PdfPCell(new Phrase("", font_normal));
                                    //data_cell.Border = 0;
                                    //data_cell.Padding = 3f;
                                    //data_cell.SetLeading(0, 1.2f);

                                    //bonus.AddCell(data_cell);


                                    Decimal Basic_Earnings = 0, BN_WG = 0, Bonus = 0, Exgr = 0, PDays = 0;
                                    for (int k = 4; k <= 12; k++)
                                    {
                                        DataRow dr_data = emplist.FindAll(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).FirstOrDefault();
                                        Basic_Earnings = 0; BN_WG = 0; Bonus = 0; Exgr = 0; PDays = 0;
                                        if (dr_data != null)
                                        {
                                            Basic_Earnings = dr_data["Basic_Earning"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Basic_Earning"]);
                                            BN_WG = dr_data["BN_WG"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["BN_WG"]);
                                            Bonus = dr_data["Bonus"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Bonus"]);
                                            Exgr = dr_data["Exgratia"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Exgratia"]);
                                            PDays = dr_data["WorkingDays"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["WorkingDays"]);

                                        }
                                        data_cell = new PdfPCell(new Phrase(FormatDValue(Basic_Earnings) + "\n" + FormatDValue(BN_WG) + "\n" + FormatDValue(Bonus) + "\n" + FormatDValue(Exgr) + "\n" + FormatDValue(PDays), font_normal));
                                        data_cell.Border = 0;
                                        data_cell.Padding = 3f;
                                        data_cell.PaddingBottom = 7f;
                                        data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                        data_cell.SetLeading(0, 1.2f);

                                        bonus.AddCell(data_cell);
                                    }

                                    for (int k = 1; k <= 3; k++)
                                    {
                                        DataRow dr_data = emplist.FindAll(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).FirstOrDefault();
                                        Basic_Earnings = 0; BN_WG = 0; Bonus = 0; Exgr = 0; PDays = 0;
                                        if (dr_data != null)
                                        {
                                            Basic_Earnings = dr_data["Basic_Earning"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Basic_Earning"]);
                                            BN_WG = dr_data["BN_WG"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["BN_WG"]);
                                            Bonus = dr_data["Bonus"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Bonus"]);
                                            Exgr = dr_data["Exgratia"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["Exgratia"]);
                                            PDays = dr_data["WorkingDays"] == DBNull.Value ? 0 : Convert.ToDecimal(dr_data["WorkingDays"]);
                                        }
                                        data_cell = new PdfPCell(new Phrase(FormatDValue(Basic_Earnings) + "\n" + FormatDValue(BN_WG) + "\n" + FormatDValue(Bonus) + "\n" + FormatDValue(Exgr) + "\n" + FormatDValue(PDays), font_normal));
                                        data_cell.Border = 0;
                                        data_cell.Padding = 3f;
                                        data_cell.PaddingBottom = 7f;
                                        data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                        data_cell.SetLeading(0, 1.2f);

                                        bonus.AddCell(data_cell);
                                    }

                                    Decimal Total_Basic_Earnings = 0, Total_BN_WG = 0, Total_Bonus = 0, Total_Exgr = 0, Total_PDays = 0;
                                    Total_Bonus = emplist.Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                    Total_Exgr = emplist.Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));
                                    Total_BN_WG = emplist.Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                    Total_Basic_Earnings = emplist.Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));
                                    Total_PDays = emplist.Sum(y => y.IsNull("WorkingDays") ? 0 : y.Field<Decimal>("WorkingDays"));

                                    //Total
                                    data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Basic_Earnings) + "\n" + FormatDValue(Total_BN_WG) + "\n" + FormatDValue(Total_Bonus) + "\n" + FormatDValue(Total_Exgr) + "\n" + FormatDValue(Total_PDays), font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Padding = 3f;
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    data_cell.SetLeading(0, 1.2f);
                                    bonus.AddCell(data_cell);

                                    //Bonus + Exg
                                    data_cell = new PdfPCell(new Phrase("\n\n\n" + FormatDValue(Total_Bonus + Total_Exgr) + "\n", font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Padding = 3f;
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    data_cell.SetLeading(0, 1.2f);
                                    bonus.AddCell(data_cell);
                                }

                                #region Department Wise Summary

                                if (j == dt_employees.Count - 1)
                                {

                                    PdfPCell dep_total = new PdfPCell();
                                    dep_total.Border = 0;
                                    dep_total.Padding = 7f;
                                    dep_total.Colspan = 2;
                                    dep_total.Border = PdfPCell.TOP_BORDER;
                                    dep_total.BorderColor = BaseColor.BLACK;
                                    bonus.AddCell(dep_total);

                                    dep_total = new PdfPCell(new Phrase("Total", font_bold));
                                    dep_total.Border = 0;
                                    
                                    dep_total.Padding = 3f;
                                    dep_total.Border = PdfPCell.TOP_BORDER;
                                    dep_total.BorderColor = BaseColor.BLACK;
                                    bonus.AddCell(dep_total);

                                    dep_total = new PdfPCell(new Phrase("Wages\nBN_WG\nBonus\nExgratia", font_bold));
                                    dep_total.Border = 0;
                                    dep_total.Padding = 3f;
                                    dep_total.SetLeading(0, 1.2f);
                                    dep_total.Border = PdfPCell.TOP_BORDER;
                                    dep_total.BorderColor = BaseColor.BLACK;
                                    bonus.AddCell(dep_total);

                                    for (int k = 4; k <= 12; k++)
                                    {
                                        var Total_Dep_Basic_Earnings = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));
                                        var Total_Dep_BN_WG = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                        var Total_Dep_Bonus = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                        var Total_Dep_Exgr = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));

                                        data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Dep_Basic_Earnings) + "\n" + FormatDValue(Total_Dep_BN_WG) + "\n" + FormatDValue(Total_Dep_Bonus) + "\n" + FormatDValue(Total_Dep_Exgr), font_normal));
                                        data_cell.Border = 0;
                                        data_cell.Border = PdfPCell.TOP_BORDER;
                                        data_cell.Padding = 3f;
                                        data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                        data_cell.SetLeading(0, 1.2f);

                                        bonus.AddCell(data_cell);
                                    }
                                    for (int k = 1; k <= 3; k++)
                                    {
                                        var Total_Dep_Basic_Earnings = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));
                                        var Total_Dep_BN_WG = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                        var Total_Dep_Bonus = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                        var Total_Dep_Exgr = dt.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));

                                        data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Dep_Basic_Earnings) + "\n" + FormatDValue(Total_Dep_BN_WG) + "\n" + FormatDValue(Total_Dep_Bonus) + "\n" + FormatDValue(Total_Dep_Exgr), font_normal));
                                        data_cell.Border = 0;
                                        data_cell.Border = PdfPCell.TOP_BORDER;
                                        data_cell.Padding = 3f;
                                        data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                        data_cell.SetLeading(0, 1.2f);

                                        bonus.AddCell(data_cell);
                                    }
                                    var Total_Bonus = dt.AsEnumerable().Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                    var Total_Exgr = dt.AsEnumerable().Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));
                                    var Total_BN_WG = dt.AsEnumerable().Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                    var Total_Basic_Earnings = dt.AsEnumerable().Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));

                                    //Total
                                    data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Basic_Earnings) + "\n" + FormatDValue(Total_BN_WG) + "\n" + FormatDValue(Total_Bonus) + "\n" + FormatDValue(Total_Exgr), font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Border = PdfPCell.TOP_BORDER;
                                    data_cell.Padding = 3f;
                                    data_cell.SetLeading(0, 1.2f);
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    bonus.AddCell(data_cell);

                                    //Bonus + Exg
                                    data_cell = new PdfPCell(new Phrase("\n\n\n" + FormatDValue(Total_Bonus + Total_Exgr) + "\n", font_normal));
                                    data_cell.Border = 0;
                                    data_cell.Border = PdfPCell.TOP_BORDER;
                                    data_cell.Padding = 3f;
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    data_cell.SetLeading(0, 1.2f);
                                    bonus.AddCell(data_cell);
                                #endregion

                                }

                            }
                            #endregion

                            doc.Add(bonus);

                            #region Overall Total Summary
                            if (i == ds.Tables[1].Rows.Count - 1)
                            {
                                doc.NewPage();
                                

                                PdfPTable company = new iTextSharp.text.pdf.PdfPTable(18);
                                company.WidthPercentage = 100f;
                                float[] comp_widths = new float[] { 4, 6, 14, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
                                company.SetWidths(comp_widths);
                                

                                PdfPCell company_hd = new PdfPCell(new Phrase(Convert.ToString(ds.Tables[0].Rows[0][0]), font_bold));
                                company_hd.Border = 0;
                                company_hd.Border = PdfPCell.TOP_BORDER;
                                company_hd.BorderColor = BaseColor.BLACK;
                                company_hd.BorderWidth = 1f;
                                company_hd.Padding = 7f;
                                company_hd.PaddingTop = 4f;
                                company_hd.PaddingLeft = 3f;
                                company_hd.Colspan = 4;
                                company.AddCell(company_hd);

                                company_hd = new PdfPCell(new Phrase("Detail of Month Wise Bonus + Exgratia For the Period of (2016-17)", font_normal));
                                company_hd.Border = 0;
                                company_hd.Border = PdfPCell.TOP_BORDER;
                                company_hd.BorderColor = BaseColor.BLACK;
                                company_hd.BorderWidth = 1f;
                                company_hd.PaddingLeft = 0f;
                                company_hd.PaddingRight = 0f;
                                company_hd.PaddingTop = 4f;
                                company_hd.PaddingBottom = 7f;

                                company_hd.Colspan = 14;
                                company_hd.HorizontalAlignment = Element.ALIGN_CENTER;
                                company.AddCell(company_hd);
                                doc.Add(company);

                                PdfPTable tbl_bonus = new iTextSharp.text.pdf.PdfPTable(18);
                                tbl_bonus.WidthPercentage = 100f;
                                float[] tbl_widths = new float[] { 1, 1, 10, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 };
                                tbl_bonus.SetWidths(tbl_widths);
                                tbl_bonus.SpacingBefore = 0f;
                                tbl_bonus.SplitRows = false;


                                DataTable dtm = ds.Tables[2];
                                setHeader(ref tbl_bonus, font_bold, 2);

                                PdfPCell dep_total = new PdfPCell();
                                dep_total.Border = 0;
                                dep_total.Padding = 7f;
                                dep_total.Colspan = 3;
                                dep_total.Border = PdfPCell.BOTTOM_BORDER;
                                dep_total.BorderColor = BaseColor.BLACK;
                                tbl_bonus.AddCell(dep_total);


                                dep_total = new PdfPCell(new Phrase("Wages\nBN_WG\nBonus\nExgratia", font_bold));
                                dep_total.Border = 0;
                                dep_total.Padding = 7f;
                                dep_total.Border = PdfPCell.BOTTOM_BORDER;
                                dep_total.BorderColor = BaseColor.BLACK;
                                tbl_bonus.AddCell(dep_total);

                                for (int k = 4; k <= 12; k++)
                                {
                                    var Total_Dep_Basic_Earnings = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));
                                    var Total_Dep_BN_WG = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                    var Total_Dep_Bonus = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                    var Total_Dep_Exgr = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2017).Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));
                                    PdfPCell data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Dep_Basic_Earnings) + "\n" + FormatDValue(Total_Dep_BN_WG) + "\n" + FormatDValue(Total_Dep_Bonus) + "\n" + FormatDValue(Total_Dep_Exgr), font_bold));
                                    data_cell.Border = 0;
                                    data_cell.Border = PdfPCell.BOTTOM_BORDER;
                                    data_cell.Padding = 3f;
                                    data_cell.SetLeading(0, 1.2f);
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    tbl_bonus.AddCell(data_cell);


                                }

                                for (int k = 1; k <= 3; k++)
                                {
                                    var Total_Dep_Basic_Earnings = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));
                                    var Total_Dep_BN_WG = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                    var Total_Dep_Bonus = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                    var Total_Dep_Exgr = dtm.AsEnumerable().Where(x => x.Field<Int32>("SrMonth") == k && x.Field<Int32>("SrYear") == 2018).Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));

                                    PdfPCell data_cell = new PdfPCell(new Phrase(FormatDValue(Total_Dep_Basic_Earnings) + "\n" + FormatDValue(Total_Dep_BN_WG) + "\n" + FormatDValue(Total_Dep_Bonus) + "\n" + FormatDValue(Total_Dep_Exgr), font_bold));
                                    data_cell.Border = 0;
                                    data_cell.Border = PdfPCell.BOTTOM_BORDER;
                                    data_cell.Padding = 3f;
                                    data_cell.SetLeading(0, 1.2f);
                                    data_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                    tbl_bonus.AddCell(data_cell);
                                }
                                var Total_Bonus = dtm.AsEnumerable().Sum(y => y.IsNull("Bonus") ? 0 : y.Field<Decimal>("Bonus"));
                                var Total_Exgr = dtm.AsEnumerable().Sum(y => y.IsNull("Exgratia") ? 0 : y.Field<Decimal>("Exgratia"));
                                var Total_BN_WG = dtm.AsEnumerable().Sum(y => y.IsNull("BN_WG") ? 0 : y.Field<Decimal>("BN_WG"));
                                var Total_Basic_Earnings = dtm.AsEnumerable().Sum(y => y.IsNull("Basic_Earning") ? 0 : y.Field<Decimal>("Basic_Earning"));

                                //Total
                                PdfPCell total_cell = new PdfPCell(new Phrase(FormatDValue(Total_Basic_Earnings) + "\n" + FormatDValue(Total_BN_WG) + "\n" + FormatDValue(Total_Bonus) + "\n" + FormatDValue(Total_Exgr), font_bold));
                                total_cell.Border = 0;
                                total_cell.Border = PdfPCell.BOTTOM_BORDER;
                                total_cell.Padding = 3f;
                                total_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                total_cell.SetLeading(0, 1.2f);
                                tbl_bonus.AddCell(total_cell);

                                //Bonus + Exg
                                total_cell = new PdfPCell(new Phrase("\n\n\n" + FormatDValue(Total_Bonus + Total_Exgr) + "\n", font_bold));
                                total_cell.Border = 0;
                                total_cell.Border = PdfPCell.BOTTOM_BORDER;
                                total_cell.Padding = 3f;
                                total_cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                                total_cell.SetLeading(0, 1.2f);

                                tbl_bonus.AddCell(total_cell);
                                doc.Add(tbl_bonus);
                            }
                            #endregion
                        }

                        #endregion
                        doc.Close();
                        Response.Write(doc);
                    }
                    catch
                    {

                    }
                    finally
                    {
                        writer.Close();
                        Response.End();
                    }
                }
            }

        }





        public void setHeader(ref PdfPTable bonus, Font font_normal, Int32 type)
        {
            if (type == 1)
            {
                PdfPCell header_cell = new PdfPCell(new Phrase("SN", font_normal));
                header_cell.Border = 0;
                header_cell.Padding = 7f;
                header_cell.PaddingLeft = 2f;
                header_cell.PaddingRight = 2f;
                header_cell.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                header_cell.BorderColor = BaseColor.BLACK;
                header_cell.BorderWidth = 1f;
                bonus.AddCell(header_cell);

                header_cell = new PdfPCell(new Phrase("Code", font_normal));
                header_cell.Border = 0;
                
                header_cell.Padding = 7f;
                header_cell.PaddingLeft = 2f;
                header_cell.PaddingRight = 2f;
                header_cell.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                header_cell.BorderColor = BaseColor.BLACK;
                header_cell.BorderWidth = 1f;
                bonus.AddCell(header_cell);

                header_cell = new PdfPCell(new Phrase("Emp Name" + Environment.NewLine + "Desig", font_normal));
                header_cell.Border = 0;
                header_cell.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                header_cell.BorderColor = BaseColor.BLACK;
                header_cell.BorderWidth = 1f;
                header_cell.Padding = 7f;
                header_cell.PaddingLeft = 2f;
                header_cell.PaddingRight = 2f;
                bonus.AddCell(header_cell);
            }
            else if (type == 2)
            {
               

                PdfPCell dep_total = new PdfPCell(new Phrase("Total Summary", font_normal));
                dep_total.Border = 0;
                dep_total.Padding = 7f;
                dep_total.PaddingLeft = 3f;
                dep_total.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                dep_total.BorderColor = BaseColor.BLACK;
                dep_total.BorderWidth = 1f;
                dep_total.HorizontalAlignment = Element.ALIGN_LEFT;
                dep_total.Colspan = 3;
                bonus.AddCell(dep_total);
            }

            PdfPCell header_cell_2 = new PdfPCell(new Phrase("", font_normal));
            header_cell_2.Border = 0;
            header_cell_2.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
            header_cell_2.BorderColor = BaseColor.BLACK;
            header_cell_2.BorderWidth = 1f;
            header_cell_2.PaddingTop = 7f;
            header_cell_2.PaddingBottom = 7f;
            header_cell_2.PaddingLeft = 2f;
            header_cell_2.PaddingRight = 2f;
            bonus.AddCell(header_cell_2);

            String[] months = new String[12] { "Apr-2017", "May-2017", "Jun-2017", "Jul-2017", "Aug-2017", "Sep-2017", "Oct-2017", "Nov-2017", "Dec-2017", "Jan-2018", "Feb-2018", "Mar-2018" };

            for (int i = 0; i < months.Length; i++)
            {
                header_cell_2 = new PdfPCell(new Phrase(months[i], font_normal));
                header_cell_2.Border = 0;
                header_cell_2.PaddingTop = 7f;
                header_cell_2.PaddingBottom = 7f;
                header_cell_2.PaddingLeft = 2f;
                header_cell_2.PaddingRight = 2f;
                header_cell_2.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                header_cell_2.BorderColor = BaseColor.BLACK;
                header_cell_2.BorderWidth = 1f;
                header_cell_2.HorizontalAlignment = Element.ALIGN_RIGHT;
                bonus.AddCell(header_cell_2);
            }

            header_cell_2 = new PdfPCell(new Phrase("Total", font_normal));
            header_cell_2.Border = 0;
            header_cell_2.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
            header_cell_2.BorderColor = BaseColor.BLACK;
            header_cell_2.BorderWidth = 1f;
            header_cell_2.HorizontalAlignment = Element.ALIGN_CENTER;
            header_cell_2.PaddingTop = 7f;
            header_cell_2.PaddingBottom = 7f;
            header_cell_2.PaddingLeft = 3f;
            header_cell_2.PaddingRight = 3f;
            header_cell_2.HorizontalAlignment = Element.ALIGN_RIGHT;
            bonus.AddCell(header_cell_2);

            header_cell_2 = new PdfPCell(new Phrase("Bns+Exg", font_normal));
            header_cell_2.Border = 0;
            header_cell_2.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
            header_cell_2.BorderColor = BaseColor.BLACK;
            header_cell_2.BorderWidth = 1f;
            header_cell_2.PaddingTop = 7f;
            header_cell_2.PaddingBottom = 7f;
            header_cell_2.PaddingLeft = 3f;
            header_cell_2.PaddingRight = 3f;
            header_cell_2.HorizontalAlignment = Element.ALIGN_RIGHT;
            bonus.AddCell(header_cell_2);

        }
        private String FormatDValue(Decimal v)
        {
            if (v == 0)
            {
                return "--";
            }
            else return v.ToString("#.##");
        }
        protected void btnClick_Click(object sender, EventArgs e)
        {


        }
    }
    public class Header : PdfPageEventHelper
    {
        public override void OnEndPage(PdfWriter writer, Document document)
        {
            base.OnEndPage(writer, document);



            PdfPTable tbl_header = new iTextSharp.text.pdf.PdfPTable(1);
            tbl_header.LockedWidth = true;
            tbl_header.TotalWidth = document.Right - document.Left;
            tbl_header.SetWidths(new int[] { 100 });

            Font font_normal = new Font(Font.FontFamily.TIMES_ROMAN, 8f);
            font_normal.SetStyle(Font.NORMAL);

            PdfPCell pageno = new PdfPCell(new Phrase(writer.PageNumber < 10 ? "Page 0" + writer.PageNumber : "Page " + writer.PageNumber, font_normal));
            pageno.Border = 0;
            pageno.Padding = 5;
            pageno.HorizontalAlignment = Element.ALIGN_CENTER;
            tbl_header.AddCell(pageno);

            tbl_header.WriteSelectedRows(0, -1, 426, document.Bottom + 9f, writer.DirectContentUnder);

        }
        public override void OnOpenDocument(PdfWriter writer, Document document)
        {
            base.OnOpenDocument(writer, document);

        }
        public override void OnCloseDocument(PdfWriter writer, Document document)
        {
            base.OnCloseDocument(writer, document);


        }
        public override void OnStartPage(PdfWriter writer, Document document)
        {
            base.OnStartPage(writer, document);
        }
    }

}