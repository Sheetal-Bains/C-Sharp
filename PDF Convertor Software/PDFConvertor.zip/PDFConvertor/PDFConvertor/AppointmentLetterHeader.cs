﻿using HRMSBusinessEntityLayer.Employee;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace HRMSServices.PdfGeneration
{
    public class AppointmentLetterHeader : PdfPageEventHelper
    {

        Font font_12f;
        Font font_12f_boldunderline;
        Font font_12f_bold;
        Boolean _IsDraft;
        BE_Employee_AppointmentLetter letter = null;
        Trainee tr = null;
        public AppointmentLetterHeader(BE_Employee_AppointmentLetter data, Boolean IsDraft,Font arialNarrow,Trainee trn)
        {
            font_12f = new Font(arialNarrow);
            font_12f.Size = 12f;
            font_12f_boldunderline = new Font(font_12f);
            font_12f_boldunderline.SetStyle(Font.BOLD | Font.UNDERLINE);
            font_12f_bold = new Font(font_12f);
            font_12f_bold.SetStyle(Font.BOLD);
            _IsDraft = IsDraft;
            letter = data;
            tr = trn;
        }

        public override void OnEndPage(PdfWriter writer, Document document)
        {
            base.OnEndPage(writer, document);
            font_12f.Color = BaseColor.BLACK;

            PdfPTable tbl_policyfooter = new iTextSharp.text.pdf.PdfPTable(1);
            tbl_policyfooter.LockedWidth = true;
            tbl_policyfooter.TotalWidth = document.Right - document.Left;
            tbl_policyfooter.SetWidths(new int[] { 100 });

            Int32 totalpages = letter.EmployeeCTC != null ? letter.EmployeeCTC.Count > 0 ? 3 : 2 : 2;
            if (tr != null)
                totalpages = 2;
            PdfPCell policy_cell = new PdfPCell(new Phrase("Doc. No." + letter.Policy.DocumentNo + "/ Issue:" + letter.Policy.Issue + "/ Revision:" + letter.Policy.Revision + "/ Date:" + letter.Policy.PolicyDate.ToString("dd.MM.yy") + "/Page " + writer.PageNumber + " of "+totalpages+"/ Approved By:" + letter.Policy.ApprovedBy, font_12f));
            policy_cell.Border = 0;
            policy_cell.Padding = 0;
            policy_cell.HorizontalAlignment = Element.ALIGN_LEFT;
            tbl_policyfooter.AddCell(policy_cell);



            if (writer.PageNumber == 1)
            {
                tbl_policyfooter.WriteSelectedRows(0, -1, 36f, document.Bottom-27f, writer.DirectContentUnder);

                PdfPTable tbl_footer = new iTextSharp.text.pdf.PdfPTable(1);
                tbl_footer.LockedWidth = true;
                tbl_footer.TotalWidth = document.Right - document.Left;
                tbl_footer.SetWidths(new int[] { 100 });

                PdfPCell footer_cell2 = new PdfPCell(new Phrase("-contd-", font_12f));
                footer_cell2.Border = 0;
                footer_cell2.Padding = 5;
                footer_cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
                tbl_footer.AddCell(footer_cell2);

                tbl_footer.WriteSelectedRows(0, -1, 36, document.Bottom, writer.DirectContentUnder);
            }
            else
            {
                tbl_policyfooter.WriteSelectedRows(0, -1, 36f, document.Bottom+36f, writer.DirectContentUnder);

                PdfPTable tbl_header = new iTextSharp.text.pdf.PdfPTable(1);
                tbl_header.LockedWidth = true;
                tbl_header.TotalWidth = document.Right - document.Left;
                tbl_header.SetWidths(new int[] { 100 });

                PdfPCell pageno = new PdfPCell(new Phrase(writer.PageNumber < 10 ? "-0" + writer.PageNumber + "-" : "-" + writer.PageNumber + "-", font_12f));
                pageno.Border = 0;
                pageno.Padding = 5;
                pageno.HorizontalAlignment = Element.ALIGN_CENTER;
                tbl_header.AddCell(pageno);

                tbl_header.WriteSelectedRows(0, -1, 36, document.Top + 26f, writer.DirectContentUnder);
            }
            if (_IsDraft)
            {
                PdfHelper.DrawWaterMark(writer, document);
            }
        }
        public override void OnOpenDocument(PdfWriter writer, Document document)
        {
            if (writer.PageNumber == 1)
            {
                //if (letter.HasLogo > 0)
                //{
                //    iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(HostingEnvironment.MapPath("~/PdfGeneration/images/kpllogo.jpg"));
                //    img.ScaleAbsolute(0.7f * img.Width, 0.7f * img.Height);
                //    img.SetAbsolutePosition(((document.Right + document.Left) / 2) - ((0.7f * img.Width) / 2), document.Top);
                //    document.Add(img);
                //}
                //else
                //{
                //    Font font_14f_boldunderline = new Font(font_10f_boldunderline);
                //    font_14f_boldunderline.Size = 14f;

                //    PdfPTable tbl_header = new iTextSharp.text.pdf.PdfPTable(1);
                //    tbl_header.LockedWidth = true;
                //    tbl_header.TotalWidth = document.Right - document.Left;
                //    tbl_header.SetWidths(new int[] { 100 });

                //    PdfPCell header = new PdfPCell(new Phrase(letter.CompanyName.ToUpper(), font_14f_boldunderline));
                //    header.Border = 0;
                //    header.Padding = 5;
                //    header.PaddingRight = 10f;
                //    header.HorizontalAlignment = Element.ALIGN_CENTER;
                //    tbl_header.AddCell(header);
                //    tbl_header.WriteSelectedRows(0, -1, 36, document.Top -18f, writer.DirectContentUnder);

                //}

            }

        }
        public override void OnCloseDocument(PdfWriter writer, Document document)
        {
            base.OnCloseDocument(writer, document);


        }
        public override void OnStartPage(PdfWriter writer, Document document)
        {
            base.OnStartPage(writer, document);
        }
    }
}