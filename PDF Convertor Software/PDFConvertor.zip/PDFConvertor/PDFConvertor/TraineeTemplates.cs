﻿using System;
using System.Collections.Generic;

namespace HRMSServices.PdfGeneration
{
    public enum TraineeGrade
    {
        TraineeOfficer,
        TraineeStaff,
        TraineeWorker
    }

    public abstract class Trainee
    {
        public List<string> listUnCommonPnts = new List<string>();

        public List<string> GetPoints()
        {
            List<string> listPoints = new List<string>();
            //Add Common Point 1
            //
            // Point 3
            listPoints.Add("On completion of Two years training, unless otherwise written communication is issued by the Company, your training period to be" +
                             "considered as extended. During the period of training, your services are liable to be terminated without any notice and without " +
                             "assigning any reason whatsoever.");
            // Point 4
            listPoints.Add(@"Your training will be governed by the rules and regulations of the company as applicable from time to time.");
            // Point 5
            listPoints.Add("You will not indulge in any activity subversive to the interests of the company.");
            // Point 6
            listPoints.Add("You will not disclose any information acquired by you during the course of your training to any agency/person without "
                             + "prior permission of the Management.");
            // Point 7
            listPoints.Add("The training contract letter is subject to the correctness of the information furnished by you in the Application form and "
                            + "also at the time of interview with us. During the course of training with us, if at any time, the information already "
                            + "furnished by you is found incorrect, your training will stand automatically terminated.");
            // Adding UnCommon Points
            var unCommonPnts = UnCommonPoints();
            var listUnCommonPnts = unCommonPnts.Item1;
            var indexOfPoint = unCommonPnts.Item2;
            foreach (var point in listUnCommonPnts)
            {
                listPoints.Insert(indexOfPoint++, point);
            }

            return listPoints;
        }

        public abstract Tuple<List<string>, int> UnCommonPoints();
    }

    public class TraineeDiploma : Trainee
    {
        public override Tuple<List<string>, int> UnCommonPoints()
        {
            listUnCommonPnts.Add(@"Your training period will be of Two years from the date of your joining. During your training period for first year,
                                    your stipend will be Rs. 11,000/- (Rupees Eleven Thousand) per month only. However, if your work and conduct is found
                                    satisfactory, stipend for second year will be revised to Rs.12500/- (Rupees twelve thousand Five Hundred) per month only.

                                    However, Management reserves the right to extend, curtail your training period and terminate your services at anytime at its discretion without assigning any
                                    reason whatsoever.
                                \");
            return Tuple.Create<List<string>, int>(listUnCommonPnts, 1);
        }
    }

    public class TraineeFactory
    {
        public static Trainee GetTraineeType(string traineeGradeName)
        {
            Trainee trainee;
            var traineeTypes = new Dictionary<string, TraineeGrade> {
    { "TRAINEE-OFF.", TraineeGrade.TraineeOfficer },
    { "TRAINEE-STAFF", TraineeGrade.TraineeStaff},
    { "TRAINEE-W", TraineeGrade.TraineeWorker}
};
            if (!traineeTypes.ContainsKey(traineeGradeName))
                return null;
            var traineeGrade = traineeTypes[traineeGradeName];
            switch (traineeGrade)
            {
                case TraineeGrade.TraineeStaff:
                    {
                        trainee = new TraineeDiploma();
                        break;
                    }
                case TraineeGrade.TraineeWorker:
                    {
                        trainee = new TraineeITI();
                        break;
                    }
                default:
                    {
                        trainee = null;
                        break;
                    }
            }
            return trainee;
        }
    }

    public class TraineeITI : Trainee
    {
        public override Tuple<List<string>, int> UnCommonPoints()
        {
            listUnCommonPnts.Add(@"Your training period will be of Two years from the date of your joining. During your training period, your stipend will be as under:-

-  For first 6 months – Minimum Wage of Un-skilled Grade     (As per notification of Pb. Govt.)

-  For next  1.5 Years - Minimum Wage of  Semi-skilled Grade (As per notification of Pb. Govt.)

	However, Management reserves the right to extend, curtail your training period and terminate your services  at  anytime at its discretion without assigning any reason whatsoever.
");
            return Tuple.Create<List<string>, int>(listUnCommonPnts, 1);
        }
    }
}