﻿using HRMSBusinessEntityLayer.PayRoll;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMSServices.PdfGeneration.Payroll
{
    public class SalarySummary
    {
        public Font font_14f { get; set; }
        
        public Font font_16f { get; set; }
        public Font font_16f_bold { get; set; }

        public Font font_20f { get; set; }
        public Font font_20f_bold { get; set; }

        public Boolean IsDraft { get; set; }

        public SalarySummary(Font font_14f, Font font_16f, Font font_16f_bold,Font font_20f, Font font_20f_bold, Boolean IsDraft)
        {
            this.font_14f = font_14f;
            this.font_16f = font_16f;
            this.font_16f_bold = font_16f_bold;
            this.font_20f = font_20f;
            this.font_20f_bold = font_20f_bold;

            this.IsDraft = IsDraft;
        }

        public Boolean GeneratePDF(BE_Report_SalarySummary data, Document doc, PdfWriter writer)
        {
            Boolean rt = false;
            try
            {
                writer.PageEvent = new PayrollPDFHeader(IsDraft, font_14f);
                doc.SetPageSize(iTextSharp.text.PageSize.A2);
                doc.Open();
                doc.SetMargins(9f, 9f, 72f, 72f);

                var tableCounter = 1;
                foreach (var smry in data.Summary)
                {
                    float[] widths = new float[] { 10, 10, 10, 10, 10, 12, 12, 14, 12 };

                    PdfPTable salary = new iTextSharp.text.pdf.PdfPTable(9);
                    salary.SetWidths(widths);
                    salary.SpacingAfter = 36f;
                    salary.SpacingBefore = 72f;

                    // Row 1 company row
                    PdfPCell cell_company = new PdfPCell(new Phrase(smry.Company,font_20f_bold));
                    cell_company.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell_company.VerticalAlignment = Element.ALIGN_MIDDLE;
                    cell_company.Border = 0;
                    cell_company.Colspan = 9;
                    cell_company.FixedHeight = 40f;
                    salary.AddCell(cell_company);

                    // Row 2 summary type
                    PdfPCell cell_group = new PdfPCell(new Phrase(smry.GroupByPDFLabel, font_16f));
                    cell_group.HorizontalAlignment = Element.ALIGN_CENTER;
                    cell_group.VerticalAlignment = Element.ALIGN_MIDDLE;
                    cell_group.Border = 0;
                    cell_group.Colspan = 9;
                    cell_group.FixedHeight = 35f;
                    salary.AddCell(cell_group);

                    // Row 3 summary header
                    SetSummaryHeader(salary);

                    //Employee earning table
                    List<BE_Report_SalaryDetail> earning = data.Earning.FindAll(x => x.GroupByID == smry.GroupByID);

                    SetSummaryEarning(salary, earning);

                    //Employee deduction table
                    List<BE_Report_SalaryDetail> deduction = data.Deduction.FindAll(x => x.GroupByID == smry.GroupByID);

                    SetSummaryDeduction(salary, deduction);

                    // Bank Payment
                    List<BE_Report_SalarySummaryComponent> banksmry = data.BankSummary.FindAll(x => x.GroupByID == smry.GroupByID);

                    SetSummaryPayment(salary, banksmry, false);

                    // Other
                    List<BE_Report_SalarySummaryComponent> othersmry = data.OtherSummary.FindAll(x => x.GroupByID == smry.GroupByID);

                    SetSummaryPayment(salary, othersmry, true);

                    // FOOTER 
                    Int32 ctcTotal = 0;
                    ctcTotal = earning.Sum(x => x.CTCAmount);

                    Int32 earTotal = 0;
                    earTotal = earning.Sum(x => x.Amount);

                    Int32 dedTotal = 0;
                    dedTotal = deduction.Sum(x => x.Amount);

                    SetSummaryFooter(salary, ctcTotal, earTotal, dedTotal);

                    doc.Add(salary);

                    // Signature table
                    SetSummarySignature(doc, data.Signature);

                    doc.NewPage();

                    tableCounter += 1;
                }

                rt = true;
            }
            catch (Exception e)
            {
                rt = false;
                throw e;
            }

            return rt;
        }

        private void SetSummaryHeader(PdfPTable salary)
        {
            PdfPCell cell_particular = new PdfPCell(new Phrase("Particular", font_16f));
            cell_particular.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_particular.BorderWidthRight = 0;
            cell_particular.FixedHeight = 30f;
            salary.AddCell(cell_particular);

            PdfPCell cell_salary = new PdfPCell(new Phrase("Salary", font_16f));
            cell_salary.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_salary.BorderWidthRight = 0;
            cell_salary.BorderWidthLeft = 0;
            salary.AddCell(cell_salary);

            PdfPCell cell_earning = new PdfPCell(new Phrase("Earning", font_16f));
            cell_earning.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_earning.BorderWidthLeft = 0;
            cell_earning.BorderWidthRight = 0;
            salary.AddCell(cell_earning);

            PdfPCell cell_deduction = new PdfPCell(new Phrase("Deduction", font_16f));
            cell_deduction.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_deduction.BorderWidthLeft =0;
            cell_deduction.BorderWidthRight = 0;
            cell_deduction.Colspan = 2;
            salary.AddCell(cell_deduction);

            PdfPCell cell_payment = new PdfPCell(new Phrase("M-O-Payment", font_16f));
            cell_payment.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_payment.Colspan = 2;
            cell_payment.BorderWidthLeft = 0;
            cell_payment.BorderWidthRight = 0;
            salary.AddCell(cell_payment);

            PdfPCell cell_other = new PdfPCell(new Phrase("Other", font_16f));
            cell_other.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_other.Colspan = 2;
            cell_other.BorderWidthLeft = 0;
            salary.AddCell(cell_other);
        }

        private void SetSummaryEarning(PdfPTable salary, List<BE_Report_SalaryDetail> earning)
        {
            PdfPTable tbl_earning = new iTextSharp.text.pdf.PdfPTable(3);
            PdfPCell cell_empearning = new PdfPCell(tbl_earning);
            cell_empearning.Colspan = 3;
            cell_empearning.Border = 0;
            tbl_earning.TotalWidth = cell_empearning.Width;
            tbl_earning.SetWidths(new float[] { 34, 33, 33 });

            foreach (var earn in earning)
            {
                PdfPCell cell_head = new PdfPCell(new Phrase(earn.SalaryHeadCode, font_14f));
                cell_head.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_head.BorderWidthRight = 0;
                cell_head.BorderWidthTop = 0;
                cell_head.BorderWidthBottom = 0;
                cell_head.FixedHeight = 25f;
                tbl_earning.AddCell(cell_head);

                PdfPCell cell_ctc = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.CTCAmount), font_14f));
                cell_ctc.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_ctc.Border = 0;
                tbl_earning.AddCell(cell_ctc);

                PdfPCell cell_amt = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.Amount), font_14f));
                cell_amt.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_amt.Border = 0;
                tbl_earning.AddCell(cell_amt);
            }

            salary.AddCell(cell_empearning);
        }

        private void SetSummaryDeduction(PdfPTable salary, List<BE_Report_SalaryDetail> deduction)
        {
            PdfPTable tbl_deduction = new iTextSharp.text.pdf.PdfPTable(2);
            PdfPCell cell_empdeduction = new PdfPCell(tbl_deduction);
            cell_empdeduction.Colspan = 2;
            cell_empdeduction.Border = 0;
            tbl_deduction.TotalWidth = cell_empdeduction.Width;
            tbl_deduction.SetWidths(new float[] { 60, 40 });

            foreach (var earn in deduction)
            {

                PdfPCell cell_head = new PdfPCell(new Phrase(earn.SalaryHeadCode, font_14f));
                cell_head.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_head.Border = 0;
                cell_head.FixedHeight = 25f;
                tbl_deduction.AddCell(cell_head);

                PdfPCell cell_amt = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.Amount), font_14f));
                cell_amt.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_amt.Border = 0;
                tbl_deduction.AddCell(cell_amt);
            }

            salary.AddCell(cell_empdeduction);
        }

        private void SetSummaryPayment(PdfPTable salary, List<BE_Report_SalarySummaryComponent> bank, bool IsLastCol)
        {
            PdfPTable tbl_deduction = new iTextSharp.text.pdf.PdfPTable(2);
            PdfPCell cell_bank = new PdfPCell(tbl_deduction);
            cell_bank.Colspan = 2;
            cell_bank.Border = 0;
            tbl_deduction.TotalWidth = cell_bank.Width;
            tbl_deduction.SetWidths(new float[] { 60, 40 });

            foreach (var detail in bank)
            {
                PdfPCell cell_head = new PdfPCell(new Phrase(detail.Component, font_14f));
                cell_head.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_head.Border = 0;
                cell_head.FixedHeight = 25f;
                tbl_deduction.AddCell(cell_head);

                PdfPCell cell_amt = new PdfPCell(new Phrase(string.Format("{0:n0}", detail.Value), font_14f));
                cell_amt.HorizontalAlignment = Element.ALIGN_RIGHT;
                if (IsLastCol) 
                {
                    cell_amt.BorderWidthBottom = 0;
                    cell_amt.BorderWidthLeft = 0;
                    cell_amt.BorderWidthTop = 0;
                    cell_amt.PaddingRight = 5F;
                }
                else
                    cell_amt.Border = 0;
                tbl_deduction.AddCell(cell_amt);
            }

            salary.AddCell(cell_bank);
        }

        private void SetSummaryFooter(PdfPTable salary, Int32 ctcTotal, Int32 earTotal, Int32 dedTotal)
        {

            PdfPCell cell_earlbltotal = new PdfPCell(new Phrase("TOTAL", font_16f));
            cell_earlbltotal.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_earlbltotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_earlbltotal.BorderWidthRight = 0;
            cell_earlbltotal.FixedHeight = 30f;
            salary.AddCell(cell_earlbltotal);

            PdfPCell cell_ctctotal = new PdfPCell(new Phrase(string.Format("{0:n0}", ctcTotal), font_16f));
            cell_ctctotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_ctctotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_ctctotal.BorderWidthLeft = 0;
            cell_ctctotal.BorderWidthRight = 0;
            salary.AddCell(cell_ctctotal);

            PdfPCell cell_eartotal = new PdfPCell(new Phrase(string.Format("{0:n0}", earTotal), font_16f));
            cell_eartotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_eartotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_eartotal.BorderWidthLeft = 0;
            cell_eartotal.BorderWidthRight = 0;
            salary.AddCell(cell_eartotal);

            PdfPCell cell_dedlbltotal = new PdfPCell(new Phrase(""));
            cell_dedlbltotal.BorderWidthRight = 0;
            cell_dedlbltotal.BorderWidthLeft = 0;
            salary.AddCell(cell_dedlbltotal);

            PdfPCell cell_dedtotal = new PdfPCell(new Phrase(string.Format("{0:n0}", dedTotal), font_16f));
            cell_dedtotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_dedtotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_dedtotal.BorderWidthLeft = 0;
            cell_dedtotal.BorderWidthRight = 0;
            salary.AddCell(cell_dedtotal);

            PdfPCell cell_attlbltotal = new PdfPCell(new Phrase(""));
            cell_attlbltotal.BorderWidthRight = 0;
            cell_attlbltotal.BorderWidthLeft = 0;
            cell_attlbltotal.Colspan = 2;
            salary.AddCell(cell_attlbltotal);

            PdfPCell cell_lblnet = new PdfPCell(new Phrase("Net Payment", font_16f));
            cell_lblnet.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_lblnet.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_lblnet.BorderWidthRight = 0;
            cell_lblnet.BorderWidthLeft = 0;
            salary.AddCell(cell_lblnet);

            PdfPCell cell_nettotal = new PdfPCell(new Phrase(string.Format("{0:n0}", (earTotal - dedTotal)), font_16f));
            cell_nettotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_nettotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_nettotal.BorderWidthLeft = 0;
            salary.AddCell(cell_nettotal);

        }

        private void SetSummarySignature(Document doc, List<BE_Report_SalarySummarySignature> sign)
        {
            PdfPTable tbl_sign = new iTextSharp.text.pdf.PdfPTable(sign.Count);
            tbl_sign.SpacingAfter = 36f;
            tbl_sign.SpacingBefore = 288f;

            foreach (var authority in sign)
            {
                PdfPTable tbl_authority = new iTextSharp.text.pdf.PdfPTable(1);

                PdfPCell cell_head = new PdfPCell(new Phrase(authority.Head, font_16f));
                cell_head.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_head.Border = 0;
                cell_head.FixedHeight = 25f;
                tbl_authority.AddCell(cell_head);

                PdfPCell cell_department = new PdfPCell(new Phrase(authority.Department, font_16f));
                cell_department.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_department.Border = 0;
                tbl_authority.AddCell(cell_department);

                PdfPCell cell_authority = new PdfPCell(tbl_authority);
                cell_authority.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_authority.Border = 0;

                tbl_sign.AddCell(cell_authority);
            }

            doc.Add(tbl_sign); 
        }

    }
}