﻿using HRMSBusinessEntityLayer.PayRoll;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRMSServices.PdfGeneration.Payroll
{
    public class SalarySlip
    {
        public Font font_12f { get; set; }
        public Boolean IsDraft { get; set; }

        public SalarySlip(Font font_12f, Boolean IsDraft)
        {
            this.font_12f = font_12f;
            this.IsDraft = IsDraft;
        }

        public Boolean GeneratePDF(BE_SalaryProcess_ReportSalarySlip data, Document doc, PdfWriter writer)
        {
            Boolean rt = false;
            try
            {
                writer.PageEvent = new PayrollPDFHeader(IsDraft, font_12f);
                doc.SetPageSize(iTextSharp.text.PageSize.A2);
                doc.Open();
                doc.SetMargins(36f, 36f, 72f, 72f);

                var tableCounter = 1;
                foreach (var emp in data.Employee)
                {
                    float[] widths = new float[] { 8, 16, 12, 8, 8, 12, 8, 6, 6, 16 };

                    PdfPTable salary = new iTextSharp.text.pdf.PdfPTable(10);
                    salary.TotalWidth = doc.Right - doc.Left;
                    salary.SetWidths(widths);
                    salary.SpacingAfter = 36f;
                    salary.SpacingBefore = 72f;

                    //Header Row1 and Row 2
                    SetSalarySlipHeader(salary, emp);

                    // ROW 3
                    // NESTED TABLE FOR EMPLOYEE TABLE
                    // NESTED ROW 1
                    SetSalarySlipPersonalDetail(salary, emp);

                    //Employee earning table
                    List<BE_Report_SalaryDetail> earning = data.Earning.FindAll(x => x.EmployeeID == emp.EmployeeID);

                    SetSalarySlipEarning(salary, earning);

                    //Employee deduction table
                    List<BE_Report_SalaryDetail> deduction = data.Deduction.FindAll(x => x.EmployeeID == emp.EmployeeID);

                    SetSalarySlipDeduction(salary, deduction);

                    BE_SalaryProcess_StepAttendanceSummary atte = data.Attendance.FirstOrDefault(x => x.EmployeeID == emp.EmployeeID);

                    // NESTED TABLE FOR EMPLOYEE ATTENDANCE
                    SetSalarySlipAttendance(salary, atte);

                    // ROW 3 LOCATION
                    PdfPTable tbl_loc = new iTextSharp.text.pdf.PdfPTable(1);
                    PdfPCell cell_loc = new PdfPCell(new Phrase(emp.LocationName));
                    cell_loc.HorizontalAlignment = Element.ALIGN_CENTER;
                    tbl_loc.AddCell(cell_loc);
                    PdfPCell cell_location = new PdfPCell(tbl_loc);
                    cell_location.HorizontalAlignment = Element.ALIGN_CENTER;
                    salary.AddCell(cell_location);

                    // FOOTER 
                    Int32 ctcTotal = 0;
                    ctcTotal = earning.Sum(x => x.CTCAmount);

                    Int32 earTotal = 0;
                    earTotal = earning.Sum(x => x.Amount);

                    Int32 dedTotal = 0;
                    dedTotal = deduction.Sum(x => x.Amount);

                    decimal attTotal = 0;
                    attTotal += atte.TotalPresent += atte.RestDays += atte.NHCount += atte.CL += atte.EL += atte.CPL;
                    attTotal += atte.SPL += atte.OSD;

                    SetSalarySlipFooter(salary, ctcTotal, earTotal, dedTotal, attTotal);

                    doc.Add(salary);

                    if ((tableCounter % 3) == 0)
                        doc.NewPage();

                    tableCounter += 1;
                }

                rt = true;
            }
            catch (Exception e)
            {
                rt = false;
                throw e;
            }

            return rt;
        }

        private void SetSalarySlipHeader(PdfPTable salary, BE_Report_Employee emp)
        {
            // ROW 1
            Phrase phrow1 = new Phrase(emp.EmployeeCode.ToString() + "          " + emp.CompanyName, font_12f);
            PdfPCell cell_empcode = new PdfPCell(phrow1);
            cell_empcode.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_empcode.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_empcode.FixedHeight = 30f;
            cell_empcode.Colspan = 10;
            cell_empcode.PaddingLeft = 5f;
            salary.AddCell(cell_empcode);

            // ROW 2
            String salcycle = emp.SalaryCycle;
            if (salcycle.Split(' ')[0].Length > 5)
                salcycle = salcycle.Replace(salcycle.Split(' ')[0], salcycle.Split(' ')[0].Substring(0,3));

            PdfPCell cell_cycle = new PdfPCell(new Phrase(salcycle, font_12f));
            cell_cycle.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_cycle.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_cycle.FixedHeight = 30f;
            cell_cycle.PaddingLeft = 5f;
            salary.AddCell(cell_cycle);

            PdfPCell cell_personal = new PdfPCell(new Phrase("PERSONAL DETAIL", font_12f));
            cell_personal.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_personal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_personal.BorderWidthLeft = 0;
            salary.AddCell(cell_personal);

            PdfPCell cell_rate = new PdfPCell(new Phrase("RATE OF SALARY", font_12f));
            cell_rate.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_rate.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_rate.Colspan = 2;
            cell_rate.BorderWidthLeft = 0;
            cell_rate.PaddingLeft = 5f;
            salary.AddCell(cell_rate);

            PdfPCell cell_earning = new PdfPCell(new Phrase("EARNING", font_12f));
            cell_earning.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_earning.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_earning.BorderWidthLeft = 0;
            salary.AddCell(cell_earning);

            PdfPCell cell_deduction = new PdfPCell(new Phrase("DEDUCTION", font_12f));
            cell_deduction.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_deduction.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_deduction.Colspan = 2;
            cell_deduction.BorderWidthLeft = 0;
            salary.AddCell(cell_deduction);

            PdfPCell cell_attendance = new PdfPCell(new Phrase("MONTH STATUS", font_12f));
            cell_attendance.HorizontalAlignment = Element.ALIGN_CENTER;
            cell_attendance.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_attendance.Colspan = 2;
            cell_attendance.BorderWidthLeft = 0;
            salary.AddCell(cell_attendance);

            PdfPCell cell_headerlast = new PdfPCell(new Phrase("", font_12f));
            cell_headerlast.BorderWidthLeft = 0;
            salary.AddCell(cell_headerlast);

        }

        private void SetSalarySlipPersonalDetail(PdfPTable salary, BE_Report_Employee emp)
        {
            PdfPTable tbl_detail = new iTextSharp.text.pdf.PdfPTable(2);

            PdfPCell cell_detail = new PdfPCell(tbl_detail);
            cell_detail.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_detail.Colspan = 2;
            tbl_detail.TotalWidth = cell_detail.Width;
            tbl_detail.SetWidths(new float[] { 33, 67 });

            PdfPCell cell_lblname = new PdfPCell();
            cell_lblname.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_lblname.VerticalAlignment = Element.ALIGN_TOP;
            cell_lblname.BorderWidth = 0;
            cell_lblname.FixedHeight = 20f;
            cell_lblname.PaddingLeft = 5f;

            // NESTED ROW 1
            cell_lblname.Phrase = new Phrase("NAME", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.EmployeeName, font_12f);
            tbl_detail.AddCell(cell_lblname);

            
            // NESTED ROW 2
            cell_lblname.Phrase = new Phrase("DESG", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.EmployeeDesignation, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 3
            cell_lblname.Phrase = new Phrase("DEPT", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.EmployeeDepartment, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 4
            cell_lblname.Phrase = new Phrase("GRADE", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.EmployeeGrade, font_12f);
            tbl_detail.AddCell(cell_lblname);
          
            // NESTED ROW 5
            cell_lblname.Phrase = new Phrase("DOB", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.DOB, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 6
            cell_lblname.Phrase = new Phrase("DOJ", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.DOJ, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 7
            cell_lblname.Phrase = new Phrase("PFNO", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.PFNumber, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 8
            cell_lblname.Phrase = new Phrase("UAN", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.UAN, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 9
            cell_lblname.Phrase = new Phrase("BANK_AC", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.BankAccount, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 10
            cell_lblname.Phrase = new Phrase("PAN", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.PAN, font_12f);
            tbl_detail.AddCell(cell_lblname);

            // NESTED ROW 11
            cell_lblname.Phrase = new Phrase("ESI_NO", font_12f);
            tbl_detail.AddCell(cell_lblname);

            cell_lblname.Phrase = new Phrase(emp.ESINumber, font_12f);
            tbl_detail.AddCell(cell_lblname);

            if (Convert.ToDecimal(emp.OTHour) > 0)
            {
                // NESTED ROW 12
                cell_lblname.Phrase = new Phrase("OT Rate", font_12f);
                tbl_detail.AddCell(cell_lblname);

                cell_lblname.Phrase = new Phrase(emp.OTRate.ToString(), font_12f);
                tbl_detail.AddCell(cell_lblname);

                // NESTED ROW 13
                cell_lblname.Phrase = new Phrase("OT Hour", font_12f);
                tbl_detail.AddCell(cell_lblname);

                cell_lblname.Phrase = new Phrase(emp.OTHour.ToString(), font_12f);
                tbl_detail.AddCell(cell_lblname);

            }

            if (Convert.ToDecimal(emp.PFEarning) > 0)
            {
                cell_lblname.Phrase = new Phrase("PF Earning", font_12f);
                tbl_detail.AddCell(cell_lblname);

                cell_lblname.Phrase = new Phrase(emp.PFEarning.ToString(), font_12f);
                tbl_detail.AddCell(cell_lblname);
            }
            if (Convert.ToDecimal(emp.ESIEarning) > 0)
            {
                cell_lblname.Phrase = new Phrase("ESI Earning", font_12f);
                tbl_detail.AddCell(cell_lblname);

                cell_lblname.Phrase = new Phrase(emp.ESIEarning.ToString(), font_12f);
                tbl_detail.AddCell(cell_lblname);
            }

            salary.AddCell(cell_detail);
        }

        private void SetSalarySlipEarning(PdfPTable salary, List<BE_Report_SalaryDetail> earning)
        {
            PdfPTable tbl_earning = new iTextSharp.text.pdf.PdfPTable(3);
            PdfPCell cell_empearning = new PdfPCell(tbl_earning);
            cell_empearning.Colspan = 3;
            tbl_earning.TotalWidth = cell_empearning.Width;
            tbl_earning.SetWidths(new float[] { 44, 27, 29 });

            foreach (var earn in earning)
            {
                PdfPCell cell_head = new PdfPCell(new Phrase(earn.SalaryHeadCode, font_12f));
                cell_head.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_head.VerticalAlignment = Element.ALIGN_TOP;
                cell_head.FixedHeight = 20f;
                cell_head.BorderWidth = 0;
                cell_head.PaddingLeft = 5f;
                tbl_earning.AddCell(cell_head);

                PdfPCell cell_ctc = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.CTCAmount), font_12f));
                cell_ctc.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_ctc.VerticalAlignment = Element.ALIGN_TOP;
                cell_ctc.BorderWidth = 0;
                cell_ctc.PaddingRight = 5f;
                tbl_earning.AddCell(cell_ctc);

                PdfPCell cell_amt = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.Amount), font_12f));
                cell_amt.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_amt.VerticalAlignment = Element.ALIGN_TOP;
                cell_amt.BorderWidth = 0;
                cell_amt.PaddingRight = 5f;
                tbl_earning.AddCell(cell_amt);

            }

            salary.AddCell(cell_empearning);
        }

        private void SetSalarySlipDeduction(PdfPTable salary, List<BE_Report_SalaryDetail> deduction)
        {
            PdfPTable tbl_deduction = new iTextSharp.text.pdf.PdfPTable(2);
            PdfPCell cell_empdeduction = new PdfPCell(tbl_deduction);
            cell_empdeduction.Colspan = 2;
            tbl_deduction.TotalWidth = cell_empdeduction.Width;
            tbl_deduction.SetWidths(new float[] { 60, 40 });

            foreach (var earn in deduction)
            {

                PdfPCell cell_head = new PdfPCell(new Phrase(earn.SalaryHeadCode, font_12f));
                cell_head.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_head.VerticalAlignment = Element.ALIGN_TOP;
                cell_head.FixedHeight = 20f;
                cell_head.BorderWidth = 0;
                cell_head.PaddingLeft = 5f;
                tbl_deduction.AddCell(cell_head);

                PdfPCell cell_amt = new PdfPCell(new Phrase(string.Format("{0:n0}", earn.Amount), font_12f));
                cell_amt.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell_amt.VerticalAlignment = Element.ALIGN_TOP;
                cell_amt.BorderWidth = 0;
                cell_amt.PaddingRight = 5f;
                tbl_deduction.AddCell(cell_amt);
            }

            salary.AddCell(cell_empdeduction);
        }

        private void SetSalarySlipAttendance(PdfPTable salary, BE_SalaryProcess_StepAttendanceSummary atte)
        {

            // NESTED ROW 1
            PdfPTable tbl_attendate = new iTextSharp.text.pdf.PdfPTable(2);
            PdfPCell cell_attendace = new PdfPCell(tbl_attendate);
            cell_attendace.Colspan = 2;
            cell_attendace.Border = 0;
            tbl_attendate.TotalWidth = cell_attendace.Width;
            tbl_attendate.SetWidths(new float[] { 60, 40 });

            PdfPCell cell_lblwday = new PdfPCell();
            cell_lblwday.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_lblwday.VerticalAlignment = Element.ALIGN_TOP;
            cell_lblwday.FixedHeight = 20f;
            cell_lblwday.BorderWidth = 0;
            cell_lblwday.PaddingLeft = 5f;

            PdfPCell cell_lblvalue = new PdfPCell();
            cell_lblvalue.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_lblvalue.VerticalAlignment = Element.ALIGN_TOP;
            cell_lblvalue.FixedHeight = 20f;
            cell_lblvalue.BorderWidth = 0;
            cell_lblvalue.PaddingRight = 5f;

            // NESTED ROW 1
            cell_lblwday.Phrase = new Phrase("W_DAY", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.TotalPresent.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 2
            cell_lblwday.Phrase = new Phrase("REST", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.RestDays.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 3
            cell_lblwday.Phrase = new Phrase("NH", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.NHCount.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 4
            cell_lblwday.Phrase = new Phrase("CL", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.CL.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 5
            cell_lblwday.Phrase = new Phrase("EL", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.EL.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 6
            cell_lblwday.Phrase = new Phrase("CPL", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.CPL.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 6
            cell_lblwday.Phrase = new Phrase("LWP", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.LWP.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 7
            cell_lblwday.Phrase = new Phrase("SPL", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.SPL.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 8
            cell_lblwday.Phrase = new Phrase("ABS", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.FullAbsent.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // NESTED ROW 8
            cell_lblwday.Phrase = new Phrase("OSD", font_12f);
            tbl_attendate.AddCell(cell_lblwday);

            cell_lblvalue.Phrase = new Phrase(atte.OSD.ToString(), font_12f);
            tbl_attendate.AddCell(cell_lblvalue);

            // ROW 3 ATTENDANCE
            salary.AddCell(cell_attendace);
        }

        private void SetSalarySlipFooter(PdfPTable salary, Int32 ctcTotal, Int32 earTotal, Int32 dedTotal, decimal attTotal)
        {
            PdfPCell cell_footer = new PdfPCell(new Phrase(""));
            cell_footer.Colspan = 2;
            salary.AddCell(cell_footer);

            PdfPCell cell_earlbltotal = new PdfPCell(new Phrase("TOTAL", font_12f));
            cell_earlbltotal.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_earlbltotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_earlbltotal.FixedHeight = 30f;
            cell_earlbltotal.BorderWidthRight = 0;
            cell_earlbltotal.BorderWidthLeft = 0;
            cell_earlbltotal.PaddingLeft = 5f;
            salary.AddCell(cell_earlbltotal);

            PdfPCell cell_ctctotal = new PdfPCell(new Phrase(string.Format("{0:n0}", ctcTotal), font_12f));
            cell_ctctotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_ctctotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_ctctotal.BorderWidthLeft = 0;
            cell_ctctotal.PaddingRight = 5f;
            salary.AddCell(cell_ctctotal);

            PdfPCell cell_eartotal = new PdfPCell(new Phrase(string.Format("{0:n0}", earTotal), font_12f));
            cell_eartotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_eartotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_eartotal.BorderWidthLeft = 0;
            cell_eartotal.PaddingRight = 5f;
            salary.AddCell(cell_eartotal);

            PdfPCell cell_dedlbltotal = new PdfPCell(new Phrase("TOTAL", font_12f));
            cell_dedlbltotal.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_dedlbltotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_dedlbltotal.BorderWidthRight = 0;
            cell_dedlbltotal.BorderWidthLeft = 0;
            cell_dedlbltotal.PaddingLeft = 5f;
            salary.AddCell(cell_dedlbltotal);

            PdfPCell cell_dedtotal = new PdfPCell(new Phrase(string.Format("{0:n0}", dedTotal), font_12f));
            cell_dedtotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_dedtotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_dedtotal.BorderWidthLeft = 0;
            cell_dedtotal.PaddingRight = 5f;
            salary.AddCell(cell_dedtotal);

            PdfPCell cell_attlbltotal = new PdfPCell(new Phrase("TOTAL", font_12f));
            cell_attlbltotal.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_attlbltotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_attlbltotal.BorderWidthRight = 0;
            cell_attlbltotal.BorderWidthLeft = 0;
            cell_attlbltotal.PaddingLeft = 5f;
            salary.AddCell(cell_attlbltotal);

            PdfPCell cell_atttotal = new PdfPCell(new Phrase(attTotal.ToString(), font_12f));
            cell_atttotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_atttotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_atttotal.BorderWidthLeft = 0;
            cell_atttotal.PaddingRight = 5f;
            salary.AddCell(cell_atttotal);

            PdfPTable tbl_net = new iTextSharp.text.pdf.PdfPTable(2);
            PdfPCell cell_net = new PdfPCell(tbl_net);
            cell_net.Border = 0;
            tbl_net.TotalWidth = cell_net.Width;
            tbl_net.SetWidths(new float[] { 50, 50 });

            PdfPCell cell_lblnet = new PdfPCell(new Phrase("Net - Pyl.", font_12f));
            cell_lblnet.HorizontalAlignment = Element.ALIGN_LEFT;
            cell_lblnet.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_lblnet.FixedHeight = 30f;
            cell_lblnet.PaddingLeft = 5f;
            tbl_net.AddCell(cell_lblnet);

            PdfPCell cell_nettotal = new PdfPCell(new Phrase(string.Format("{0:n0}", (earTotal - dedTotal)), font_12f));
            cell_nettotal.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell_nettotal.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell_nettotal.BorderWidthLeft = 0;
            cell_nettotal.PaddingRight = 5f;
            tbl_net.AddCell(cell_nettotal);

            salary.AddCell(cell_net);
        }

    }
}