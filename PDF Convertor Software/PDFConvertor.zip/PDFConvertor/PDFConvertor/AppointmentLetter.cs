﻿using HRMSBusinessEntityLayer.Employee;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Hosting;

namespace HRMSServices.PdfGeneration
{
    public class AppointmentLetter
    {
        public Boolean GeneratePDF(BE_Employee_AppointmentLetter data, Boolean IsDraft, String filename)
        {
            // Trainee
            Trainee trainee = TraineeFactory.GetTraineeType(data.GradeCode);
            if (trainee != null)
            {
                bool result = GeneratePDFTrainee(data, IsDraft, filename, trainee);
                return result;
            }
            // Trainee End
            FileStream fs = null; Document doc = null; PdfWriter writer = null;
            Boolean rt = false;
            try
            {
                fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Write);
                doc = new Document(iTextSharp.text.PageSize.A4, 36f, 36f, 90f, 90f);
                writer = PdfWriter.GetInstance(doc, fs);

                BaseFont customfont = BaseFont.CreateFont(HostingEnvironment.MapPath("~/PdfGeneration/fonts/arialn.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED);
                Font font_12f = new Font(customfont, 12f);
                writer.PageEvent = new AppointmentLetterHeader(data, IsDraft, font_12f,trainee);
                doc.Open();
                doc.SetMargins(36f, 36f, 36f, 36f);

                font_12f.Size = 12f;

                Font font_12f_boldunderline = new Font(font_12f);
                font_12f_boldunderline.SetStyle(Font.BOLD | Font.UNDERLINE);

                Font font_12f_bold = new Font(font_12f);
                font_12f_bold.SetStyle(Font.BOLD);

                PdfPTable tbl_address = new iTextSharp.text.pdf.PdfPTable(1);
                tbl_address.SpacingAfter = 10f;
                tbl_address.WidthPercentage = 100;
                tbl_address.SpacingBefore = 72f;

                String abrv = "";
                if (data.CompanyName.IndexOf("Esteem") > -1)
                {
                    abrv = "EFL";
                }
                else if (data.CompanyName.IndexOf("Green") > -1)
                {
                    abrv = "GEL";
                }
                else
                    abrv = "KPL";

                String SonOrDaughterOf = "";
                if (data.Gender == "Male")
                    SonOrDaughterOf = "S/o";
                else if (data.Gender == "Female")
                    SonOrDaughterOf = "D/o";

                if (SonOrDaughterOf != "")
                {
                    if (!String.IsNullOrWhiteSpace(data.FatherName))
                        SonOrDaughterOf = SonOrDaughterOf + "." + data.FatherName;
                }
                else
                {
                    if (!String.IsNullOrWhiteSpace(data.FatherName))
                    {
                        SonOrDaughterOf = "F.Name: " + data.FatherName;
                    }
                }

                String location = "";
                if (!String.IsNullOrWhiteSpace(data.CityName))
                {
                    location = data.CityName;
                }

                if (location != "")
                {
                    if (data.PinCode != "")
                        location = location + "-" + data.PinCode;
                }
                else
                {
                    if (data.PinCode != "")
                        location = data.PinCode;
                }



                if (String.IsNullOrWhiteSpace(data.DistrictName))
                {
                    if (String.IsNullOrWhiteSpace(data.StateName) == false)
                        location = location + " (" + data.StateName + ")";
                }
                else
                {
                    if (!String.IsNullOrWhiteSpace(data.CityName) && !String.IsNullOrWhiteSpace(data.StateName))
                    {
                        if (data.DistrictName != data.CityName)
                            location = location + Environment.NewLine + "District:- " + data.DistrictName + " (" + data.StateName + ")";
                        else if (data.StateName != data.CityName)
                            location = location + " (" + data.StateName + ")";
                    }
                    else if (String.IsNullOrWhiteSpace(data.CityName) && String.IsNullOrWhiteSpace(data.StateName))
                    {
                        location = location + Environment.NewLine + "District:- " + data.DistrictName;
                    }
                    else if (String.IsNullOrWhiteSpace(data.CityName) && !String.IsNullOrWhiteSpace(data.StateName))
                    {
                        location = location + Environment.NewLine + "District:- " + data.DistrictName + " (" + data.StateName + ")";
                    }
                    else if (!String.IsNullOrWhiteSpace(data.CityName) && String.IsNullOrWhiteSpace(data.StateName))
                    {
                        if (data.DistrictName != data.CityName)
                            location = location + Environment.NewLine + "District:- " + data.DistrictName;
                    }


                }
                String Address2 = String.IsNullOrWhiteSpace(data.AddressLine2) ? "" : Environment.NewLine + data.AddressLine2;
                String addressText = abrv + "/Pers./" + data.EmployeeCode + "/" + data.DOJ.ToString("MM-yy") + "/"
                                    + Environment.NewLine
                                    + data.DOJ.ToString("MMM dd, yyyy")
                                    + Environment.NewLine + Environment.NewLine
                                    + data.Title + " " + data.EmployeeName
                                    + Environment.NewLine
                                    + SonOrDaughterOf + ". " + data.FatherName
                                    + Environment.NewLine
                                    + data.AddressLine1
                                    + Address2
                                    + Environment.NewLine
                                    + location;

                Phrase address_phrase = new Phrase(addressText, font_12f);

                PdfPCell cell_address = new PdfPCell(address_phrase);
                cell_address.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_address.SetLeading(0, 1.3f);
                cell_address.Border = 0;
                cell_address.PaddingLeft = 0f;
                tbl_address.AddCell(cell_address);

                String subject = data.IsRetainer == 1 ? "Appointment as Retainer" : "Appointment Letter";
                PdfPCell cell_EmployeeName = new PdfPCell(new Phrase(Environment.NewLine + "Dear " + data.Title + " " + data.EmployeeName + "\n\nSub: " + subject, font_12f_bold));
                cell_EmployeeName.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_EmployeeName.SetLeading(0, 1.0f);
                cell_EmployeeName.Border = 0;
                cell_EmployeeName.PaddingLeft = 0f;
                tbl_address.AddCell(cell_EmployeeName);
                doc.Add(tbl_address);

                iTextSharp.text.List lt = new iTextSharp.text.List(true);
                String doj = data.DOJ.ToString("dd.MM.yyyy");
                List<String> points = new List<String>();
                if (data.IsRetainer == 0)
                {
                    String text = "With reference to your application and subsequent interview you had with us, we are pleased to appoint you as " + data.GradeName + ", in Grade " + data.GradeCode + " in " + data.DepartmentName + " w.e.f. " + doj + " on pay & perks as detailed in Annexure “A” on the following terms & conditions:-";
                    Paragraph ph = new Paragraph(text, font_12f);
                    ph.SpacingBefore = 0f;
                    ph.SpacingAfter = 10f;
                    ph.SetLeading(0, 1.3f);
                    doc.Add(ph);

                    // 1st Point
                    points.Add("You will be on probation for a period of 1 year w.e.f. " + doj + ", which may be extended by a further period at the discretion of management."
                            + Environment.NewLine + Environment.NewLine
                            + "Your period of probation shall be deemed to be automatically extended unless and until written communication is issued by company in writing. "
                            + "During probation your services can be terminated without notice and without assigning any reason whatsoever.");

                    // 2nd Point
                    points.Add("After confirmation of your services in writing either party can terminate this contract of employment by giving one month’s working notice"
                                + " or one month’s basic wage in lieu of notice. However, no notice or wages in lieu thereof shall be payable to you if your services are terminated"
                                + " on the ground of misconduct or violation of any other express  terms and conditions mentioned in the letter of appointment.");

                    // 4th Point

                    points.Add("Your initial place of posting will be at " + data.OfficeLocationName + " and report to Head of Department at " + data.OfficeLocationName.Split(',')[0] + "."
                            + "The company, however, reserves the right to transfer you to any of its offices, branches or place of business including that of its Group or "
                            + "Subsidiary Company and from one place to another on the terms and conditions it may be deem fit.");
                }
                else
                {
                    points.Add("Management is pleased to appoint you as " + data.GradeName + " in our organization with effect from " + doj + ". You will be designated as " + data.DesignationName + " in " + data.DepartmentName + " Department and will be paid a lump sum monthly Retainership fee of ___________/- only (i.e. Rupees _____________________only)");

                    points.Add("Your initial appointment is for the period ending on ____________, which can be extended at the discretion of the Management. If your performance is not found satisfactory during this period, your services are liable to be terminated without any notice and/or assigning any reason thereof.");

                    points.Add("In the first instance, you will be posted at Saila Khurd, District Hoshiarpur, and report to Advisor, TECH - Mgmt. The Company, however, reserves the right to transfer you to any of its offices, branches or place of business including that of its Group or Subsidiary Company and from one place to another on the terms and conditions it may deem fit.");
                }

                // 3rd Point
                if (ExcludePtsForWorker.Worker.ToString() != data.EmployeeTypeName)//Exclude this point for Worker //!Enum.GetNames(typeof(ExcludePtsForWorker)).Contains(data.EmployeeTypeName)
                    if (data.Gender == "Male" && data.MaritalStatus == "Single")
                    {
                        points.Insert(2, ("The membership of the Kuantum Club is mandatory, accordingly membership fee @ Rs.200 per month will be deducted from your salary. However, these"
                                    + "subscription charges of Kuantum Club may be modified from time to time and will be recovered accordingly."));
                    }
                    else
                    {
                        points.Insert(2, ("The membership of the Kuantum Club and Kaushalya-Ladies Club is mandatory, accordingly membership fee @ Rs.200 per month for each club (Rs. 400 P.M),"
                                    + " will be deducted from your salary. However, these subscription charges of Kuantum Club and Kaushalya-Ladies Club may be modified from time to time"
                                  + " and will be recovered accordingly."));
                    }

                // 5th Point
                points.Add("You shall be responsible for the work as assigned by your Reporting Officer or Head of Department, subject to condition that the management "
                        + "deserve the rights to modify, restrict, enlarge or amend in any manner the scope of work and also to modify, restrict duties and responsibilities "
                        + "as it may deem fit.");

                //6th Point
                points.Add("You will be required to perform or all such functions and duties under the supervision of such officers as you may be directed to do from time to time."
                         + " You will diligently and faithfully carry out the instructions given to you by your supervisors in connection with your work at the best  of your skill.");

                //7th Point
                points.Add("You will be required to observe all safety precautions under Factories Act and Rules made there under.");

                //8th Point
                points.Add("For purpose of conduct, service and disciplinary control as well as all other matters, you will be governed by the rules and regulations of the company as may be in force from time to time.");

                //9th Point
                points.Add("You will not disclose any information regarding the affairs of the company which may come to your knowledge and will not divulge any "
                        + "company Information during the course of your service. You will also not misuse any documents, tool, knowledge / Technical know how etc. pertaining to the "
                        + "affairs of the Company to promote your personal interest of business.");

                //10th Point
                points.Add("You will be entitled to Contributory Provident Fund / Medical / Leave encashment / Gratuity, etc. and other statutory benefits as per rules of company as notified from time to time.");

                //11th Point
                points.Add("As per rules of the Company, you will retire from the services of the company on attaining the age of 58 years or as modified from time to time.");

                //12th Point
                points.Add("During the course of employment, you will not secure any full/part time work with any other employer without our previous consent in writing.");

                //13th point
                points.Add("Your appointment is subject to your being medically fit. On joining, you may be asked to undergo medical fitness test at medical Centre designated for the purpose.");

                //14th point
                if (ExcludePtsForWorker.Worker.ToString() != data.EmployeeTypeName)
                    points.Add("The data generated in your computer / laptop or which come across in your system while working for the company shall be sole property of the company. You shall not delete the same at any time. It is responsibility to hand over all the data available in your system intact to the Management on its demand.");

                //15th point
                points.Add("You shall not indulge in any commercial activity / trade / chit-funding / selling of Schemes & Policies etc. with any employee of the company or his family member.");

                //16th point
                points.Add("In case of any change in the address during the course of employment, it will be your duty to intimate the management in writing within three days from the date of such change and get the changes so recorded in the register of addresses maintained for the purpose by the company. Otherwise, all communication sent you by management at your last given address will be deemed to have been received by you.");

                //17th point
                points.Add("Furnishing of false information, concealment or evasion of any factual information would be dis-qualification. In case any inaccurate information is found anytime, your employement is liable to be terminated without any notice or notice pay in lieu thereof even after confirmation of your services.");

                for (int i = 0; i < points.Count; i++)
                {
                    ListItem li = new ListItem(points[i], font_12f);
                    li.SetLeading(0, 1.3f);
                    li.Alignment = Element.ALIGN_JUSTIFIED;
                    li.SpacingAfter = 4f;
                    lt.Add(li);
                }
                doc.Add(lt);

                Paragraph signatures = new Paragraph();
                signatures.SpacingBefore = 10f;
                signatures.Alignment = Element.ALIGN_LEFT;
                Phrase forcell = new Phrase();
                Font font_for = new Font(font_12f);
                font_for.Size = 12;

                Chunk k = new Chunk("For ", font_for);
                forcell.Add(k);
                Font font_for_bold = new Font(font_for);
                font_for_bold.SetStyle(Font.BOLD);
                Chunk companyname = new Chunk(data.CompanyName, font_for_bold);
                forcell.Add(companyname);

                Phrase signature = new Phrase("\n\n\n(" + data.Signature.Name + ")\n" + data.Signature.GradeName + "\n" + data.Signature.DepartmentName, font_12f_bold);
                signatures.Add(forcell);
                signatures.Add(signature);

                doc.Add(signatures);

                PdfPTable acceptedSign = new PdfPTable(1);
                //acceptedSign.SpacingAfter = 10f;
                acceptedSign.WidthPercentage = 30;
                acceptedSign.HorizontalAlignment = Element.ALIGN_RIGHT;

                PdfPCell cell_acceptedSign = new PdfPCell(new Phrase("\n(Accepted)", font_for_bold));
                cell_acceptedSign.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_acceptedSign.Padding = 5;
                cell_acceptedSign.Border = 0;
                acceptedSign.AddCell(cell_acceptedSign);

                cell_acceptedSign = new PdfPCell(new Phrase("\n\n( ________________ )", font_for_bold));
                cell_acceptedSign.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_acceptedSign.Padding = 5;
                cell_acceptedSign.Border = 0;

                acceptedSign.AddCell(cell_acceptedSign);
                doc.Add(acceptedSign);

                // cell
                if (data.EmployeeCTC != null)
                {
                    if (data.EmployeeCTC.Count > 0)
                    {
                        doc.NewPage();
                        // CTC Part

                        Paragraph annexure_pg = new Paragraph("Annexure-A", font_12f_bold);
                        annexure_pg.Alignment = Element.ALIGN_RIGHT;
                        doc.Add(annexure_pg);

                        Font font_11 = new Font(font_12f);
                        font_11.Size = 11f;

                        Font font_11_bold = new Font(font_11);
                        font_11_bold.SetStyle(Font.BOLD);

                        Paragraph ctcFor = new Paragraph(data.Title + " " + data.EmployeeName + "\n" + data.GradeName + "\n" + data.DepartmentName, font_11_bold);
                        ctcFor.Alignment = Element.ALIGN_LEFT;
                        ctcFor.SpacingBefore = 10f;
                        doc.Add(ctcFor);

                        PdfPTable salaryTable = new PdfPTable(2);
                        salaryTable.WidthPercentage = 70;
                        salaryTable.HorizontalAlignment = Element.ALIGN_LEFT;
                        salaryTable.SpacingBefore = 20f;
                        salaryTable.SetWidths(new int[] { 65, 35 });

                        PdfPCell gradeCell = new PdfPCell(new Phrase("Grade", font_11_bold));
                        gradeCell.Border = 0;
                        gradeCell.Padding = 0;
                        salaryTable.AddCell(gradeCell);

                        PdfPCell gradeCode = new PdfPCell(new Phrase(data.GradeCode + Environment.NewLine + "\n(Rs. Per Month)", font_11_bold));
                        gradeCode.Border = 0;
                        gradeCode.Padding = 5f;
                        gradeCode.PaddingBottom = 5f;
                        gradeCode.HorizontalAlignment = Element.ALIGN_CENTER;
                        salaryTable.AddCell(gradeCode);

                        doc.Add(salaryTable);

                        salaryTable = new PdfPTable(2);
                        salaryTable.WidthPercentage = 65;
                        salaryTable.HorizontalAlignment = Element.ALIGN_LEFT;
                        salaryTable.SpacingBefore = 20f;
                        salaryTable.SetWidths(new int[] { 70, 30 });


                        List<SalaryHeads> deductions = data.EmployeeCTC.FindAll(a => a.SalaryHeadType == "D");
                        Decimal totalSum = data.EmployeeCTC.Sum(x => x.Amount);
                        Decimal totalEarnings = data.EmployeeCTC.Where(x => x.SalaryHeadType == "E").Sum(x => x.Amount);

                        data.EmployeeCTC.RemoveAll(x => x.SalaryHeadType == "D");

                        for (int i = 0; i < data.EmployeeCTC.Count; i++)
                        {
                            String name = data.EmployeeCTC[i].SalaryHeadName;
                            if (data.EmployeeCTC[i].SalaryHeadCode == "LTA")
                                name = "LTA";
                            else if (data.EmployeeCTC[i].SalaryHeadCode == "Club" || data.EmployeeCTC[i].SalaryHeadCode == "KLC")
                                name = name + " Reimb.";

                            PdfPCell earningCell = new PdfPCell(new Phrase(name, font_11));
                            earningCell.Border = 0;
                            earningCell.Padding = 0;
                            earningCell.PaddingTop = 3f;
                            earningCell.PaddingBottom = 3f;
                            salaryTable.AddCell(earningCell);

                            earningCell = new PdfPCell(new Phrase(data.EmployeeCTC[i].Amount.ToString("0.00"), font_11));
                            earningCell.Border = 0;
                            earningCell.Padding = 0;
                            earningCell.PaddingTop = 3f;
                            earningCell.PaddingBottom = 3f;
                            earningCell.HorizontalAlignment = Element.ALIGN_RIGHT;

                            salaryTable.AddCell(earningCell);
                        }

                        PdfPCell earningTotalLabel = new PdfPCell(new Phrase("Total", font_12f_bold));
                        earningTotalLabel.Border = 0;
                        earningTotalLabel.Padding = 0;
                        earningTotalLabel.PaddingRight = 5f;
                        earningTotalLabel.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(earningTotalLabel);

                        PdfPCell earningTotalValue = new PdfPCell(new Phrase(totalEarnings.ToString("0.00"), font_12f_bold));
                        earningTotalValue.Border = 0;
                        earningTotalValue.PaddingTop = 2f;
                        earningTotalValue.PaddingBottom = 5f;
                        earningTotalValue.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                        earningTotalValue.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(earningTotalValue);

                        for (int i = 0; i < deductions.Count; i++)
                        {
                            String name = deductions[i].SalaryHeadCode;
                            if (name == "Bonus")
                                name = "Bonus/ Exgratia";
                            else if (name == "Gratuity")
                                name = "Gratuity (Eligibility As per Gratuity Act)";

                            PdfPCell deductionCell = new PdfPCell(new Phrase(name, font_11));
                            deductionCell.Border = 0;

                            deductionCell.PaddingTop = 3f;
                            deductionCell.PaddingBottom = 3f;
                            salaryTable.AddCell(deductionCell);

                            deductionCell = new PdfPCell(new Phrase(deductions[i].Amount.ToString("0.00"), font_11));
                            deductionCell.Border = 0;

                            deductionCell.PaddingTop = 3f;
                            deductionCell.PaddingBottom = 3f;
                            deductionCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                            salaryTable.AddCell(deductionCell);
                        }

                        PdfPCell GrandTotalLabel = new PdfPCell(new Phrase("G. Total", font_12f_bold));
                        GrandTotalLabel.Border = 0;
                        GrandTotalLabel.Padding = 0;
                        GrandTotalLabel.PaddingRight = 5f;
                        GrandTotalLabel.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(GrandTotalLabel);

                        PdfPCell GrandTotalValue = new PdfPCell(new Phrase(totalSum.ToString("0.00"), font_12f_bold));
                        GrandTotalValue.Border = 0;
                        GrandTotalValue.PaddingTop = 2f;
                        GrandTotalValue.PaddingBottom = 5f;
                        GrandTotalValue.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                        GrandTotalValue.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(GrandTotalValue);

                        PdfPCell preparedBy = new PdfPCell(new Phrase("Prepared By:", font_11));
                        preparedBy.Border = 0;
                        preparedBy.Padding = 0;
                        preparedBy.PaddingTop = 40f;
                        preparedBy.PaddingBottom = 30f;
                        salaryTable.AddCell(preparedBy);

                        PdfPCell checkedBy = new PdfPCell(new Phrase("Checked By:", font_11));
                        checkedBy.Border = 0;
                        checkedBy.HorizontalAlignment = Element.ALIGN_RIGHT;
                        checkedBy.Padding = 0f;
                        checkedBy.PaddingBottom = 30f;
                        checkedBy.PaddingTop = 40f;
                        salaryTable.AddCell(checkedBy);

                        doc.Add(salaryTable);
                    }
                   
                }

              

                //float fg1 = writer.GetVerticalPosition(false);

                rt = true;
            }
            catch
            {
                rt = false;
            }
            finally
            {
                if (doc != null)
                {
                    if (doc.IsOpen())
                        doc.Close();
                    doc.Dispose();
                }
                if (writer != null)
                {
                    writer.Close();
                    writer.Dispose();
                }
                if (fs != null)
                {
                    fs.Close(); fs.Dispose();
                }
            }
            return rt;
        }

        public Boolean GeneratePDFTrainee(BE_Employee_AppointmentLetter data, Boolean IsDraft, String filename, Trainee trainee)
        {
            FileStream fs = null; Document doc = null; PdfWriter writer = null;
            Boolean rt = false;
            try
            {
                fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.Write);
                doc = new Document(iTextSharp.text.PageSize.A4, 36f, 36f, 90f, 90f);
                writer = PdfWriter.GetInstance(doc, fs);

                BaseFont customfont = BaseFont.CreateFont(HostingEnvironment.MapPath("~/PdfGeneration/fonts/arialn.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED);
                Font font_12f = new Font(customfont, 12f);
                writer.PageEvent = new AppointmentLetterHeader(data, IsDraft, font_12f,trainee);
                doc.Open();
                doc.SetMargins(36f, 36f, 36f, 36f);
                font_12f.Size = 12f;

                Font font_12f_boldunderline = new Font(font_12f);
                font_12f_boldunderline.SetStyle(Font.BOLD | Font.UNDERLINE);

                Font font_12f_bold = new Font(font_12f);
                font_12f_bold.SetStyle(Font.BOLD);

                PdfPTable tbl_address = new iTextSharp.text.pdf.PdfPTable(1);
                tbl_address.SpacingAfter = 10f;
                tbl_address.WidthPercentage = 100;
                tbl_address.SpacingBefore = 72f;

                String abrv = "";
                if (data.CompanyName.IndexOf("Esteem") > -1)
                {
                    abrv = "EFL";
                }
                else if (data.CompanyName.IndexOf("Green") > -1)
                {
                    abrv = "GEL";
                }
                else
                    abrv = "KPL";

                String SonOrDaughterOf = "";
                if (data.Gender == "Male")
                    SonOrDaughterOf = "S/o";
                else if (data.Gender == "Female")
                    SonOrDaughterOf = "D/o";

                if (SonOrDaughterOf != "")
                {
                    if (!String.IsNullOrWhiteSpace(data.FatherName))
                        SonOrDaughterOf = SonOrDaughterOf + "." + data.FatherName;
                }
                else
                {
                    if (!String.IsNullOrWhiteSpace(data.FatherName))
                    {
                        SonOrDaughterOf = "F.Name: " + data.FatherName;
                    }
                }

                String location = "";
                if (!String.IsNullOrWhiteSpace(data.CityName))
                {
                    location = data.CityName;
                }

                if (location != "")
                {
                    if (data.PinCode != "")
                        location = location + "-" + data.PinCode;
                }
                else
                {
                    if (data.PinCode != "")
                        location = data.PinCode;
                }



                if (String.IsNullOrWhiteSpace(data.DistrictName))
                {
                    if (String.IsNullOrWhiteSpace(data.StateName) == false)
                        location = location + " (" + data.StateName + ")";
                }
                else
                {
                    if (!String.IsNullOrWhiteSpace(data.CityName) && !String.IsNullOrWhiteSpace(data.StateName))
                    {
                        if (data.DistrictName != data.CityName)
                            location = location + Environment.NewLine + "District:- " + data.DistrictName + " (" + data.StateName + ")";
                        else if (data.StateName != data.CityName)
                            location = location + " (" + data.StateName + ")";
                    }
                    else if (String.IsNullOrWhiteSpace(data.CityName) && String.IsNullOrWhiteSpace(data.StateName))
                    {
                        location = location + Environment.NewLine + "District:- " + data.DistrictName;
                    }
                    else if (String.IsNullOrWhiteSpace(data.CityName) && !String.IsNullOrWhiteSpace(data.StateName))
                    {
                        location = location + Environment.NewLine + "District:- " + data.DistrictName + " (" + data.StateName + ")";
                    }
                    else if (!String.IsNullOrWhiteSpace(data.CityName) && String.IsNullOrWhiteSpace(data.StateName))
                    {
                        if (data.DistrictName != data.CityName)
                            location = location + Environment.NewLine + "District:- " + data.DistrictName;
                    }


                }
                String Address2 = String.IsNullOrWhiteSpace(data.AddressLine2) ? "" : Environment.NewLine + data.AddressLine2;
                String addressText = abrv + "/Pers./" + data.EmployeeCode + "/" + data.DOJ.ToString("MM-yy") + "/"
                                    + Environment.NewLine
                                    + data.DOJ.ToString("MMM dd, yyyy")
                                    + Environment.NewLine + Environment.NewLine
                                    + data.Title + " " + data.EmployeeName
                                    + Environment.NewLine
                                    + SonOrDaughterOf + ". " + data.FatherName
                                    + Environment.NewLine
                                    + data.AddressLine1
                                    + Address2
                                    + Environment.NewLine
                                    + location;

                Phrase address_phrase = new Phrase(addressText, font_12f);

                PdfPCell cell_address = new PdfPCell(address_phrase);
                cell_address.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_address.SetLeading(0, 1.3f);
                cell_address.Border = 0;
                cell_address.PaddingLeft = 0f;
                tbl_address.AddCell(cell_address);

                String subject = data.IsRetainer == 1 ? "Appointment as Retainer" : "Appointment Letter";
                PdfPCell cell_EmployeeName = new PdfPCell(new Phrase(Environment.NewLine + "Dear " + data.Title + " " + data.EmployeeName + "\n\nSub: " + subject, font_12f_bold));
                cell_EmployeeName.HorizontalAlignment = Element.ALIGN_LEFT;
                cell_EmployeeName.SetLeading(0, 1.0f);
                cell_EmployeeName.Border = 0;
                cell_EmployeeName.PaddingLeft = 0f;
                tbl_address.AddCell(cell_EmployeeName);
                doc.Add(tbl_address);

                iTextSharp.text.List lt = new iTextSharp.text.List(true);
                String doj = data.DOJ.ToString("dd.MM.yyyy");
                List<String> points = new List<String>();
                String text = "With reference to your application and subsequent interview you had with us on ________, the Management is pleased to engage you in our organization w.e.f.  " + doj + " on following terms and conditions:- ";
                Paragraph ph = new Paragraph(text, font_12f);
                ph.SpacingBefore = 0f;
                ph.SpacingAfter = 10f;
                ph.SetLeading(0, 1.3f);
                doc.Add(ph);
                //Add Designation
                //
                points.Add("Designation   -  " + data.DesignationName);
                points.AddRange(trainee.GetPoints());

                for (int i = 0; i < points.Count; i++)
                {
                    ListItem li = new ListItem(points[i], font_12f);
                    li.SetLeading(0, 1.3f);
                    li.Alignment = Element.ALIGN_JUSTIFIED;
                    li.SpacingAfter = 4f;
                    lt.Add(li);
                }
                doc.Add(lt);

                Paragraph signatures = new Paragraph();
                signatures.SpacingBefore = 10f;
                signatures.Alignment = Element.ALIGN_LEFT;
                Phrase forcell = new Phrase();
                Font font_for = new Font(font_12f);
                font_for.Size = 12;

                Chunk k = new Chunk("For ", font_for);
                forcell.Add(k);
                Font font_for_bold = new Font(font_for);
                font_for_bold.SetStyle(Font.BOLD);
                Chunk companyname = new Chunk(data.CompanyName, font_for_bold);
                forcell.Add(companyname);

                Phrase signature = new Phrase("\n\n(" + data.Signature.Name + ")\n" + data.Signature.GradeName + "\n" + data.Signature.DepartmentName, font_12f_bold);
                signatures.Add(forcell);
                signatures.Add(signature);

                doc.Add(signatures);

                PdfPTable acceptedSign = new PdfPTable(1);
                //acceptedSign.SpacingAfter = 10f;
                acceptedSign.WidthPercentage = 30;
                acceptedSign.HorizontalAlignment = Element.ALIGN_RIGHT;

                PdfPCell cell_acceptedSign = new PdfPCell(new Phrase("(Accepted)", font_for_bold));
                cell_acceptedSign.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_acceptedSign.Padding = 5;
                cell_acceptedSign.Border = 0;
                acceptedSign.AddCell(cell_acceptedSign);

                cell_acceptedSign = new PdfPCell(new Phrase("\n\n( ________________ )", font_for_bold));
                cell_acceptedSign.HorizontalAlignment = Element.ALIGN_CENTER;
                cell_acceptedSign.Padding = 5;
                cell_acceptedSign.Border = 0;

                acceptedSign.AddCell(cell_acceptedSign);
                doc.Add(acceptedSign);

                // cell

                if (data.EmployeeCTC != null)
                {
                    if (data.EmployeeCTC.Count > 0)
                    {
                        doc.NewPage();

                        // CTC Part

                        Paragraph annexure_pg = new Paragraph("Annexure-A", font_12f_bold);
                        annexure_pg.Alignment = Element.ALIGN_RIGHT;
                        doc.Add(annexure_pg);

                        Font font_11 = new Font(font_12f);
                        font_11.Size = 11f;

                        Font font_11_bold = new Font(font_11);
                        font_11_bold.SetStyle(Font.BOLD);

                        Paragraph ctcFor = new Paragraph(data.Title + " " + data.EmployeeName + "\n" + data.GradeName + "\n" + data.DepartmentName, font_11_bold);
                        ctcFor.Alignment = Element.ALIGN_LEFT;
                        ctcFor.SpacingBefore = 10f;
                        doc.Add(ctcFor);

                        PdfPTable salaryTable = new PdfPTable(2);
                        salaryTable.WidthPercentage = 70;
                        salaryTable.HorizontalAlignment = Element.ALIGN_LEFT;
                        salaryTable.SpacingBefore = 20f;
                        salaryTable.SetWidths(new int[] { 65, 35 });

                        PdfPCell gradeCell = new PdfPCell(new Phrase("Grade", font_11_bold));
                        gradeCell.Border = 0;
                        gradeCell.Padding = 0;
                        salaryTable.AddCell(gradeCell);

                        PdfPCell gradeCode = new PdfPCell(new Phrase(data.GradeCode + Environment.NewLine + "\n(Rs. Per Month)", font_11_bold));
                        gradeCode.Border = 0;
                        gradeCode.Padding = 5f;
                        gradeCode.PaddingBottom = 5f;
                        gradeCode.HorizontalAlignment = Element.ALIGN_CENTER;
                        salaryTable.AddCell(gradeCode);

                        doc.Add(salaryTable);

                        salaryTable = new PdfPTable(2);
                        salaryTable.WidthPercentage = 65;
                        salaryTable.HorizontalAlignment = Element.ALIGN_LEFT;
                        salaryTable.SpacingBefore = 20f;
                        salaryTable.SetWidths(new int[] { 70, 30 });


                        List<SalaryHeads> deductions = data.EmployeeCTC.FindAll(a => a.SalaryHeadType == "D");
                        Decimal totalSum = data.EmployeeCTC.Sum(x => x.Amount);
                        Decimal totalEarnings = data.EmployeeCTC.Where(x => x.SalaryHeadType == "E").Sum(x => x.Amount);

                        data.EmployeeCTC.RemoveAll(x => x.SalaryHeadType == "D");

                        for (int i = 0; i < data.EmployeeCTC.Count; i++)
                        {
                            String name = data.EmployeeCTC[i].SalaryHeadName;
                            if (data.EmployeeCTC[i].SalaryHeadCode == "LTA")
                                name = "LTA";
                            else if (data.EmployeeCTC[i].SalaryHeadCode == "Club" || data.EmployeeCTC[i].SalaryHeadCode == "KLC")
                                name = name + " Reimb.";

                            PdfPCell earningCell = new PdfPCell(new Phrase(name, font_11));
                            earningCell.Border = 0;
                            earningCell.Padding = 0;
                            earningCell.PaddingTop = 3f;
                            earningCell.PaddingBottom = 3f;
                            salaryTable.AddCell(earningCell);

                            earningCell = new PdfPCell(new Phrase(data.EmployeeCTC[i].Amount.ToString("0.00"), font_11));
                            earningCell.Border = 0;
                            earningCell.Padding = 0;
                            earningCell.PaddingTop = 3f;
                            earningCell.PaddingBottom = 3f;
                            earningCell.HorizontalAlignment = Element.ALIGN_RIGHT;

                            salaryTable.AddCell(earningCell);
                        }

                        PdfPCell earningTotalLabel = new PdfPCell(new Phrase("Total", font_12f_bold));
                        earningTotalLabel.Border = 0;
                        earningTotalLabel.Padding = 0;
                        earningTotalLabel.PaddingRight = 5f;
                        earningTotalLabel.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(earningTotalLabel);

                        PdfPCell earningTotalValue = new PdfPCell(new Phrase(totalEarnings.ToString("0.00"), font_12f_bold));
                        earningTotalValue.Border = 0;
                        earningTotalValue.PaddingTop = 2f;
                        earningTotalValue.PaddingBottom = 5f;
                        earningTotalValue.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                        earningTotalValue.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(earningTotalValue);

                        for (int i = 0; i < deductions.Count; i++)
                        {
                            String name = deductions[i].SalaryHeadCode;
                            if (name == "Bonus")
                                name = "Bonus/ Exgratia";
                            else if (name == "Gratuity")
                                name = "Gratuity (Eligibility As per Gratuity Act)";

                            PdfPCell deductionCell = new PdfPCell(new Phrase(name, font_11));
                            deductionCell.Border = 0;

                            deductionCell.PaddingTop = 3f;
                            deductionCell.PaddingBottom = 3f;
                            salaryTable.AddCell(deductionCell);

                            deductionCell = new PdfPCell(new Phrase(deductions[i].Amount.ToString("0.00"), font_11));
                            deductionCell.Border = 0;

                            deductionCell.PaddingTop = 3f;
                            deductionCell.PaddingBottom = 3f;
                            deductionCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                            salaryTable.AddCell(deductionCell);
                        }

                        PdfPCell GrandTotalLabel = new PdfPCell(new Phrase("G. Total", font_12f_bold));
                        GrandTotalLabel.Border = 0;
                        GrandTotalLabel.Padding = 0;
                        GrandTotalLabel.PaddingRight = 5f;
                        GrandTotalLabel.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(GrandTotalLabel);

                        PdfPCell GrandTotalValue = new PdfPCell(new Phrase(totalSum.ToString("0.00"), font_12f_bold));
                        GrandTotalValue.Border = 0;
                        GrandTotalValue.PaddingTop = 2f;
                        GrandTotalValue.PaddingBottom = 5f;
                        GrandTotalValue.Border = PdfPCell.TOP_BORDER | PdfPCell.BOTTOM_BORDER;
                        GrandTotalValue.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(GrandTotalValue);

                        PdfPCell preparedBy = new PdfPCell(new Phrase("Prepared By:", font_11));
                        preparedBy.Border = 0;
                        preparedBy.Padding = 0;
                        preparedBy.PaddingTop = 40f;
                        preparedBy.PaddingBottom = 30f;
                        salaryTable.AddCell(preparedBy);

                        PdfPCell checkedBy = new PdfPCell(new Phrase("Checked By:", font_11));
                        checkedBy.Border = 0;
                        checkedBy.Padding = 0f;
                        checkedBy.PaddingTop = 40f;
                        checkedBy.PaddingBottom = 30f;
                        checkedBy.HorizontalAlignment = Element.ALIGN_RIGHT;
                        salaryTable.AddCell(checkedBy);
                        doc.Add(salaryTable);
                    }
                }


                //float fg1 = writer.GetVerticalPosition(false);
                rt = true;
            }
            catch
            {
                rt = false;
            }
            finally
            {
                if (doc != null)
                {
                    if (doc.IsOpen())
                        doc.Close();
                    doc.Dispose();
                }
                if (writer != null)
                {
                    writer.Close(); writer.Dispose();
                }
                if (fs != null)
                {
                    fs.Close(); fs.Dispose();
                }
            }
            return rt;
        }

        private enum ExcludePtsForWorker
        {
            Worker
        }


    }
}

//For XML
//String templatename = "kpl.xml";

//using (XmlReader reader = XmlReader.Create("templates/" + templatename))
//{
//    // Move to the hire-date element.
//    reader.MoveToContent();
//    reader.ReadToDescendant("items");
//    while (reader.Read())
//    {
//        if ((reader.NodeType == XmlNodeType.Element) && (reader.Name == "item"))
//        {
//String placeholder=reader.GetAttribute("placeholder")
//            if(reader.GetAttribute("no")=="3")
//            {
//                String k = reader.ReadContentAsString();
//            }
//               // Console.WriteLine(reader.GetAttribute("currency") + ": " + reader.GetAttribute("rate"));
//        }
//    }
//}